package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.models.ContentFragmentInfo;
import com.adobe.aem.acs.bofa.core.models.ContentFragmentMerge;
import com.adobe.aem.acs.bofa.core.models.ContentFragmentVariation;
import com.adobe.aem.acs.bofa.core.services.ContentFragmentMergeService;
import com.adobe.aem.acs.bofa.core.services.ContentFragmentMergeWorkflowService;
import com.adobe.aem.acs.bofa.core.services.ContentFragmentService;
import com.adobe.aem.acs.bofa.core.services.MergeConfigService;
import com.adobe.aem.acs.bofa.core.util.BofaJcrUtils;
import com.day.crx.JcrConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.*;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.*;
import java.util.*;
import java.util.stream.Collectors;

@Component(service = {ContentFragmentMergeWorkflowService.class}, immediate = true)
public class ContentFragmentMergeWorkflowServiceImpl implements ContentFragmentMergeWorkflowService {

    private static final Logger logger = LoggerFactory.getLogger(ContentFragmentMergeWorkflowServiceImpl.class);

    @Reference
    private ContentFragmentService contentFragmentService;

    @Reference
    private ContentFragmentMergeService contentFragmentMergeService;

    @Reference
    private MergeConfigService mergeConfigService;


    public List<ContentFragmentInfo> startContentFragmentMerge(ResourceResolver resourceResolver, List<ContentFragmentInfo> contentFragmentInfoList){
        logger.debug("Starting Content Fragment merge workflow");

        try {

            String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
            Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);

            List<String> incomingContentFragmentPaths = contentFragmentInfoList.stream().map(ContentFragmentInfo::getContentFragmentPath).collect(Collectors.toList());
            logger.info("Current Content Fragment Paths: " + StringUtils.join(incomingContentFragmentPaths, ","));

            ModifiableValueMap properties = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(ModifiableValueMap.class);
            List<String> current = new ArrayList<>(Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty("contentFragmentPaths"), new String[0])));
            logger.info("Current Content Fragment Paths: " + StringUtils.join(current, ","));

            Set<String> pathSet = new HashSet<>(current);
            pathSet.addAll(incomingContentFragmentPaths);

            List<String> contentFragmentPaths = new ArrayList<>(pathSet);
            logger.info("New content fragment paths: " + StringUtils.join(contentFragmentPaths, ","));

            mergeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty("contentFragmentPaths"), contentFragmentPaths.toArray(new String[0]));
            logger.info("contentFragmentPaths: {}", StringUtils.join(contentFragmentPaths, ", "));

            for(ContentFragmentInfo contentFragmentInfo : contentFragmentInfoList){
                Node incomingContentFragmentNodeJcrContent = Objects.requireNonNull(resourceResolver.getResource(contentFragmentInfo.getContentFragmentTempPath() + "/" + JcrConstants.JCR_CONTENT)).adaptTo(Node.class);
                incomingContentFragmentNodeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_OPEN);

                Node dataNode = incomingContentFragmentNodeJcrContent.getNode("data");
                for(NodeIterator nodeIterator = dataNode.getNodes(); nodeIterator.hasNext();){
                    Node variationNode = nodeIterator.nextNode();
                    variationNode.setProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_OPEN);
                }

                ContentFragmentMerge contentFragmentMerge = contentFragmentMergeService.getContentFragmentMerge(resourceResolver, contentFragmentInfo);
                boolean hasMergeConflicts = false;
                for(ContentFragmentVariation contentFragmentVariation : contentFragmentMerge.getVariations()){
                    if(!contentFragmentVariation.isAutoMerge()){
                        hasMergeConflicts = true;
                    }
                }

                Node contentFragmentNodeJcrContent = Objects.requireNonNull(resourceResolver.getResource(contentFragmentInfo.getContentFragmentPath() + "/" + JcrConstants.JCR_CONTENT)).adaptTo(Node.class);
                logger.info("Content Fragment hasMergeConflicts: {}", hasMergeConflicts);
                Node contentFragmentMetadata = contentFragmentNodeJcrContent.getNode("metadata");
                contentFragmentMetadata.setProperty(BofaJcrUtils.getNamespacedProperty("hasMergeConflict"), hasMergeConflicts);

            }

//            resourceResolver.commit();

        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return contentFragmentInfoList;
    }


    public void addContentFragmentMissingModel(ResourceResolver resourceResolver, ContentFragmentInfo contentFragmentInfo) {

        logger.debug("Adding content fragment missing model for path {}", contentFragmentInfo.getContentFragmentPath());

        try {

            String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
            Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);

            List<String> incomingContentFragmentPaths = List.of(contentFragmentInfo.getContentFragmentPath());
            logger.info("Current Content Fragment Paths: " + StringUtils.join(incomingContentFragmentPaths, ","));

            ModifiableValueMap properties = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(ModifiableValueMap.class);
            List<String> current = new ArrayList<>(Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty("contentFragmentMissingModelPaths"), new String[0])));
            logger.info("Current Content Fragment Paths: " + StringUtils.join(current, ","));

            Set<String> pathSet = new HashSet<>(current);
            pathSet.addAll(incomingContentFragmentPaths);

            List<String> contentFragmentPaths = new ArrayList<>(pathSet);
            logger.info("New content fragment paths: " + StringUtils.join(contentFragmentPaths, ","));

            mergeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty("contentFragmentMissingModelPaths"), contentFragmentPaths.toArray(new String[0]));
            logger.info("contentFragmentPaths: {}", StringUtils.join(contentFragmentPaths, ", "));


        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

    }


    public void removeContentFragmentMissingModel(ResourceResolver resourceResolver, ContentFragmentInfo contentFragmentInfo) {

        logger.debug("Removing content fragment missing model for path {}", contentFragmentInfo.getContentFragmentPath());

        String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
        Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);

        ModifiableValueMap properties = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(ModifiableValueMap.class);
        List<String> contentFragmentMissingModelPaths = new ArrayList<>(Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty("contentFragmentMissingModelPaths"), new String[0])));
        logger.info("removeContentFragmentMissingModel before contentFragmentMissingModelPaths: " + StringUtils.join(contentFragmentMissingModelPaths, ","));

        contentFragmentMissingModelPaths.remove(contentFragmentInfo.getContentFragmentPath());

        logger.info("removeContentFragmentMissingModel after contentFragmentMissingModelPaths: " + StringUtils.join(contentFragmentMissingModelPaths, ","));
        properties.put(BofaJcrUtils.getNamespacedProperty("contentFragmentMissingModelPaths"), contentFragmentMissingModelPaths.toArray(new String[0]));
        logger.info("in here resolver.hasChanges: {}", resourceResolver.hasChanges());

//        properties.remove("");

    }



    public void closeContentFragmentMerge(ResourceResolver resourceResolver, String contentFragmentPath, String variationName){
        logger.debug("Closing Content Fragment Variation Merge variationName: {}, contentFragmentPath: {}", variationName, contentFragmentPath);

        try {

            ContentFragmentInfo contentFragmentInfo = contentFragmentService.getContentFragmentInfo(resourceResolver, contentFragmentPath);

            String contentFragmentJcrContentPath = contentFragmentInfo.getContentFragmentTempPath() + "/" + JcrConstants.JCR_CONTENT;
            Node contentFragmentJcrContent = Objects.requireNonNull(resourceResolver.getResource(contentFragmentJcrContentPath)).adaptTo(Node.class);
            assert contentFragmentJcrContent != null;

            ContentFragmentMerge contentFragmentMerge = contentFragmentMergeService.getContentFragmentMerge(resourceResolver, contentFragmentInfo);

            ContentFragmentVariation variation = contentFragmentMerge.getVariation(variationName);
            if(variation.isContentIdentical()){
                logger.info("Close content fragment merge for variation: {} content fragment: {}", variation.getName(), contentFragmentJcrContent.getPath());
                Node variationNode = contentFragmentJcrContent.getNode("data").getNode(variation.getName());
                variationNode.setProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_CLOSED);
            } else {
                throw new IllegalStateException("Cannot close content fragment merge, content is not the same");
            }

//            resourceResolver.commit();

        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }


    }


    public void endContentFragmentMerge(ResourceResolver resourceResolver){
        logger.info("End content fragment merge workflow");

        try {
            String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
            Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);
            mergeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty("status"), BofaSyncConstants.BOFA_SYNC_WORKFLOW_CLOSED);
            mergeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty("contentFragmentPaths"), new String[]{});

            Node tmpPath = Objects.requireNonNull(resourceResolver.getResource(mergeConfigService.getIncomingMergePath())).adaptTo(Node.class);
            for (NodeIterator it = tmpPath.getNodes(); it.hasNext(); ) {
                Node child = (Node) it.next();
                child.remove();
            }

//            resourceResolver.commit();

        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

    }

}
