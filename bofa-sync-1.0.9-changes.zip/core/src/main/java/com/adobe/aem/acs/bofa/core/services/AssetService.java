package com.adobe.aem.acs.bofa.core.services;

import com.adobe.aem.acs.bofa.core.models.AssetMergeMetadata;
import org.apache.sling.api.resource.ResourceResolver;

import java.util.List;

public interface AssetService {

    void checkNode(ResourceResolver resourceResolver, String path);

    AssetMergeMetadata getAssetMergeMetadata(ResourceResolver resourceResolver, String assetPath);

    List<AssetMergeMetadata> getAssetMergeMetadataList(ResourceResolver resourceResolver);

}
