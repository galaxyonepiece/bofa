package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.models.MetadataMerge;
import com.adobe.aem.acs.bofa.core.models.MetadataMergeMetadata;
import com.adobe.aem.acs.bofa.core.services.MetadataMergeService;
import com.adobe.aem.acs.bofa.core.services.MetadataMergeWorkflowService;
import com.adobe.aem.acs.bofa.core.services.MetadataService;
import com.adobe.aem.acs.bofa.core.util.BofaJcrUtils;
import com.day.crx.JcrConstants;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

@Component(service = MetadataMergeWorkflowService.class, immediate = true)
public class MetadataMergeWorkflowServiceImpl implements MetadataMergeWorkflowService {


    private static final Logger logger = LoggerFactory.getLogger(MetadataMergeWorkflowServiceImpl.class);

    @Reference
    private MetadataService metadataService;

    @Reference
    private MetadataMergeService metadataMergeService;

    public void closeMetadataMerge(ResourceResolver resourceResolver, String assetPath){
        logger.debug("Closing Metadata Merge assetPath: {}", assetPath);

        MetadataMergeMetadata metadataMergeMetadata = metadataService.getMetadataMergeMetadata(resourceResolver, assetPath);

        String assetJcrContentPath = metadataMergeMetadata.getAssetTempPath() + "/" + JcrConstants.JCR_CONTENT;
        ModifiableValueMap assetJcrContent = Objects.requireNonNull(resourceResolver.getResource(assetJcrContentPath)).adaptTo(ModifiableValueMap.class);

        MetadataMerge metadataMerge = metadataMergeService.getMetadataMerge(resourceResolver, metadataMergeMetadata);

        if(metadataMerge.isContentIdentical()){
            logger.info("Close asset merge for asset: {}", metadataMergeMetadata.getAssetPath());
            assetJcrContent.put(BofaJcrUtils.getNamespacedProperty("mergeMetadataStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_CLOSED);
        } else {
            throw new IllegalStateException("Cannot close Metadata merge, content is not the same");
        }


    }


}
