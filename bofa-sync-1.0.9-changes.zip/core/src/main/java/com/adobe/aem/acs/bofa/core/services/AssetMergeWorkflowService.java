package com.adobe.aem.acs.bofa.core.services;

import org.apache.sling.api.resource.ResourceResolver;

public interface AssetMergeWorkflowService {

    void closeAssetMerge(ResourceResolver resourceResolver, String assetPath);

}
