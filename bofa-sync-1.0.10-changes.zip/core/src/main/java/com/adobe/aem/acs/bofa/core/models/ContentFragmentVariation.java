package com.adobe.aem.acs.bofa.core.models;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class ContentFragmentVariation {

    private static final Logger logger = LoggerFactory.getLogger(ContentFragmentVariation.class);

    private String name;

    private String title;

    private List<ContentFragmentDiffField> contentFragmentDiffFields;

    private TagDiff tagDiff;

    private boolean autoMerge;

    private boolean contentIdentical;

    private String mergeStatus;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<ContentFragmentDiffField> getContentFragmentDiffFields() {
        if(contentFragmentDiffFields == null) {
            contentFragmentDiffFields = new ArrayList<>();
        }
        return contentFragmentDiffFields;
    }

    public ContentFragmentDiffField getContentFragmentDiffField(String fieldName) {
        ContentFragmentDiffField f = this.getContentFragmentDiffFields().stream().filter(fd -> fd.getName().equals(fieldName)).findFirst().orElse(null);
        if(f == null) {
            logger.error("Cannor find field with name: {}", fieldName);
        }
        return f;
    }

    public void setContentFragmentDiffFields(List<ContentFragmentDiffField> contentFragmentDiffFields) {
        this.contentFragmentDiffFields = contentFragmentDiffFields;
    }

    public TagDiff getTagDiff() {
        return tagDiff;
    }

    public void setTagDiff(TagDiff tagDiff) {
        this.tagDiff = tagDiff;
    }

    public boolean isAutoMerge() {
        return autoMerge;
    }

    public void setAutoMerge(boolean autoMerge) {
        this.autoMerge = autoMerge;
    }

    public boolean isContentIdentical() {
        return contentIdentical;
    }

    public void setContentIdentical(boolean contentIdentical) {
        this.contentIdentical = contentIdentical;
    }

    public String getMergeStatus() {
        return mergeStatus;
    }

    public void setMergeStatus(String mergeStatus) {
        this.mergeStatus = mergeStatus;
    }

}
