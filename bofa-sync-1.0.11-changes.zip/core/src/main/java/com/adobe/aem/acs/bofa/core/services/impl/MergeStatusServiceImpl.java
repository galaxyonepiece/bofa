package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.executor.JcrResolverExecutor;
import com.adobe.aem.acs.bofa.core.models.*;
import com.adobe.aem.acs.bofa.core.services.*;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

@Component(service = MergeStatusService.class, immediate = true)
public class MergeStatusServiceImpl implements MergeStatusService {


    private static final Logger logger = LoggerFactory.getLogger(MergeStatusServiceImpl.class);

    @Reference
    private JcrResolverExecutor executor;

    @Reference
    private ContentFragmentService contentFragmentService;

    @Reference
    private ContentFragmentMergeService contentFragmentMergeService;

    @Reference
    private MetadataService metadataService;

    @Reference
    private MetadataMergeService metadataMergeService;

    @Reference
    private AssetService assetService;

    @Reference
    private AssetMergeService assetMergeService;

    public Map<String, List<String>> getMergeStatus(){
        logger.info("Getting merge status paths");
        Map<String, List<String>> mergeStatus = new HashMap<>();
        try {
            executor.runReadOnly((ResourceResolver resourceResolver) -> {
                List<ContentFragmentInfo> contentFragmentInfoList = contentFragmentService.getContentFragmentInfoList(resourceResolver);
                List<ContentFragmentMerge> contentFragmentMergeList = contentFragmentMergeService.getContentFragmentMergeList(resourceResolver, contentFragmentInfoList);

                List<MetadataMergeMetadata> metadataMergeMetadataList = metadataService.getMetadataMergeMetadataList(resourceResolver);
                List<MetadataMerge> metadataMergeList = metadataMergeService.getMetadataMergeList(resourceResolver, metadataMergeMetadataList);

                List<AssetMergeMetadata> assetMergeMetadataList = assetService.getAssetMergeMetadataList(resourceResolver);


                Set<String> autoMerge = new HashSet<>();
                Set<String> manualMerge = new HashSet<>();
                Set<String> contentFragmentAutoMerge = new HashSet<>();
                Set<String> contentFragmentManualMerge = new HashSet<>();
                Set<String> metadataFragmentAutoMerge = new HashSet<>();
                Set<String> metadataManualMerge = new HashSet<>();
                Set<String> assetMerge = new HashSet<>();


                for (ContentFragmentMerge contentFragmentMerge : contentFragmentMergeList) {
                    boolean isAutoMerge = true;
                    for (ContentFragmentVariation contentFragmentVariation : contentFragmentMerge.getVariations()) {
                        if (!contentFragmentVariation.isAutoMerge()){
                            isAutoMerge = false;
                        }
                    }

                    String contentFragmentPath = contentFragmentMerge.getContentFragmentInfo().getContentFragmentPath();
                    if (isAutoMerge) {
                        autoMerge.add(contentFragmentPath);
                        contentFragmentAutoMerge.add(contentFragmentPath);
                    } else {
                        manualMerge.add(contentFragmentPath);
                        contentFragmentManualMerge.add(contentFragmentPath);
                    }
                }

                for (MetadataMerge metadataMerge : metadataMergeList) {
                    String assetPath = metadataMerge.getMetadataMergeMetadata().getAssetPath();
                    if (metadataMerge.isAutoMerge()){
                        autoMerge.add(assetPath);
                        metadataFragmentAutoMerge.add(assetPath);
                    } else {
                        manualMerge.add(assetPath);
                        metadataManualMerge.add(assetPath);
                    }
                }

                for (AssetMergeMetadata assetMergeMetadata : assetMergeMetadataList) {
                    String assetPath = assetMergeMetadata.getAssetPath();
                    assetMerge.add(assetPath);
                    manualMerge.add(assetPath);
                }

                mergeStatus.put("contentFragmentAutoMerge", new ArrayList<>(contentFragmentAutoMerge));
                mergeStatus.put("contentFragmentManualMerge", new ArrayList<>(contentFragmentManualMerge));
                mergeStatus.put("metadataFragmentAutoMerge", new ArrayList<>(metadataFragmentAutoMerge));
                mergeStatus.put("metadataManualMerge", new ArrayList<>(metadataManualMerge));
                mergeStatus.put("assetMerge", new ArrayList<>(assetMerge));

                mergeStatus.put("autoMerge", new ArrayList<>(autoMerge));
                mergeStatus.put("manualMerge", new ArrayList<>(manualMerge));

                return null;
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return mergeStatus;
    }


}
