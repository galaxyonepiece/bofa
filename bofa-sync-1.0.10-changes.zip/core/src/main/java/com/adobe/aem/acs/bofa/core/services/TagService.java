package com.adobe.aem.acs.bofa.core.services;

import com.adobe.aem.acs.bofa.core.models.TagDiff;
import com.adobe.cq.dam.cfm.ContentFragment;
import com.day.cq.dam.api.Asset;
import org.apache.sling.api.resource.ResourceResolver;

public interface TagService {

    TagDiff getTags(ResourceResolver resourceResolver, Asset source, Asset destination);

    TagDiff getTags(ResourceResolver resourceResolver, String variationName, ContentFragment source, ContentFragment destination);

}
