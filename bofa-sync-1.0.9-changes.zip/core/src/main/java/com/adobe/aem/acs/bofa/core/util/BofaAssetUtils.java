package com.adobe.aem.acs.bofa.core.util;

import com.day.cq.dam.api.Asset;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class BofaAssetUtils {


    private static final Logger logger = LoggerFactory.getLogger(BofaAssetUtils.class);

    public static boolean areBinariesEqual(Asset source, Asset destination) {

        if (source != null && destination != null) {
            try (InputStream in1 = source.getOriginal().getStream();
                 InputStream in2 = destination.getOriginal().getStream()) {

                boolean areEqual = IOUtils.contentEquals(in1, in2);
                if (!areEqual) {
                    logger.info("Assets are different.");
                }
                return areEqual;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        return false;
    }

    public static String getSha1(Asset asset) {
        MessageDigest sha1 = null;
        try {
            sha1 = MessageDigest.getInstance("SHA-1");
            DigestInputStream dis = new DigestInputStream(asset.getOriginal().getStream(), sha1);
            while (dis.read() != -1); // Read fully

            return Hex.encodeHexString(sha1.digest());
        } catch (NoSuchAlgorithmException | IOException e) {
            throw new RuntimeException(e);
        }
    }

}
