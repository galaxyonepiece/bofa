package com.adobe.aem.acs.bofa.core.config;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;


@ObjectClassDefinition(
        name = "BofA Merge Configuration",
        description = "Configuration for Merge Settings in AEM"
)
public @interface BofaMergeConfig {

    @AttributeDefinition(name = "incomingChangesFolder", description = "Temporary Incoming Content Fragment Folder, this will be appended to " + BofaSyncConstants.BOFA_SYNC_MERGE_PATH)
    String incomingChangesFolder() default "author2";

    @AttributeDefinition(name = "outgoingChangesFolder", description = "Temporary Outgoing Content Fragment Folder, this will be appended to " + BofaSyncConstants.BOFA_SYNC_MERGE_PATH)
    String outgoingChangesFolder() default "author1";

    @AttributeDefinition(name = "metadataListPath", description = "Path to the list of Metadata Fields to be merged")
    String metadataListPath() default "/etc/acs-commons/lists/metadata";

}
