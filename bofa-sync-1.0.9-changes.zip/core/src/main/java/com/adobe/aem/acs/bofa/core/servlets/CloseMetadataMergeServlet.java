package com.adobe.aem.acs.bofa.core.servlets;

import com.adobe.aem.acs.bofa.core.executor.JcrResolverExecutor;
import com.adobe.aem.acs.bofa.core.services.MetadataMergeWorkflowService;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import java.io.IOException;

@Component(service = Servlet.class, property = {Constants.SERVICE_DESCRIPTION + "= Close Metadata Merge",
        "sling.servlet.paths=" + "/bin/closeMetadataMerge", "sling.servlet.methods=" + HttpConstants.METHOD_GET
})
public class CloseMetadataMergeServlet extends SlingSafeMethodsServlet {

    private static final Logger logger = LoggerFactory.getLogger(CloseMetadataMergeServlet.class);

    @Reference
    JcrResolverExecutor executor;

    @Reference
    private MetadataMergeWorkflowService metadataMergeWorkflowService;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        String assetPath = request.getParameter("assetPath");
        logger.info("Close merge for asset: {}", assetPath);

        try {
            executor.runWithWriteAccess((ResourceResolver resourceResolver) -> {
                metadataMergeWorkflowService.closeMetadataMerge(resourceResolver, assetPath);
                return null;
            });
        } catch (Exception e) {
            response.setStatus(500);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"success\": false}");

            throw new RuntimeException(e);
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write("{\"success\": true}");

    }


}
