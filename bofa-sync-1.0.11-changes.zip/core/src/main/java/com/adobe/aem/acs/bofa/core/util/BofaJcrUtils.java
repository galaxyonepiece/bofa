package com.adobe.aem.acs.bofa.core.util;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.models.ContentFragmentInfo;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import java.util.*;

import static com.adobe.aem.acs.bofa.core.constants.BofaJcrPropertyConstants.*;

public class BofaJcrUtils {


    private static final Logger logger = LoggerFactory.getLogger(BofaJcrUtils.class);

    public static String getNamespacedProperty(String property) {
        return String.format("%s:%s", BofaSyncConstants.BOFA_JCR_NAMESPACE, property);
    }


    public static void addPathToProperty(ModifiableValueMap mergeProperties, String path, String property) {
        Set<String> closedContentFragmentPaths = BofaJcrUtils.getPathSet(mergeProperties, property);
        closedContentFragmentPaths.add(path);
        List<String> updatedClosedContentFragmentPaths = new ArrayList<>(closedContentFragmentPaths);
        mergeProperties.put(BofaJcrUtils.getNamespacedProperty(property), updatedClosedContentFragmentPaths.toArray(new String[0]));
    }


    public static void removePathFromProperty(ModifiableValueMap mergeProperties, String path, String property) {
        logger.info("Removing path {} from property {}", path, property);
        Set<String> contentFragmentPaths = BofaJcrUtils.getPathSet(mergeProperties, property);
        contentFragmentPaths.remove(path);
        List<String> updatedContentFragmentPaths = new ArrayList<>(contentFragmentPaths);
        mergeProperties.put(BofaJcrUtils.getNamespacedProperty(property), updatedContentFragmentPaths.toArray(new String[0]));
    }


    public static Set<String> getPathSet(ModifiableValueMap properties, String property) {

        // get the list of existing content fragment paths stored in PROP_CONTENT_FRAGMENT_PATHS
        List<String> current = Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty(property), new String[0]));
        logger.info("Existing getPathSet paths: {}", StringUtils.join(current, ","));

        Set<String> existingContentPathSet = new HashSet<>(current);
//        existingContentPathSet.addAll(incomingContentFragmentPaths);
        return existingContentPathSet;

    }


    public static boolean isAssetInUse(ModifiableValueMap mergeProperties, String contentFragmentPath, String excludeProperty) {
        List<String> propertyPaths = new ArrayList<>(List.of(PROP_ASSET_PATHS, PROP_ASSET_METADATA_PATHS));
        propertyPaths.remove(excludeProperty);
        return isPathInUse(mergeProperties, propertyPaths, contentFragmentPath);
    }


    public static boolean isAssetInUse(ModifiableValueMap mergeProperties, String contentFragmentPath) {
        List<String> propertyPaths = List.of(PROP_ASSET_PATHS, PROP_ASSET_METADATA_PATHS);
        return isPathInUse(mergeProperties, propertyPaths, contentFragmentPath);
    }


    public static boolean isContentFragmentInUse(ModifiableValueMap mergeProperties, String contentFragmentPath) {
        List<String> propertyPaths = List.of(PROP_CONTENT_FRAGMENT_PATHS, PROP_ASSET_METADATA_PATHS);
        return isPathInUse(mergeProperties, propertyPaths, contentFragmentPath);
    }


    public static boolean isContentFragmentInUse(ModifiableValueMap mergeProperties, String contentFragmentPath, String excludeProperty) {
        List<String> propertyPaths = new ArrayList<>(List.of(PROP_CONTENT_FRAGMENT_PATHS, PROP_ASSET_METADATA_PATHS));
        propertyPaths.remove(excludeProperty);
        return isPathInUse(mergeProperties, propertyPaths, contentFragmentPath);
    }


    private static boolean isPathInUse(ModifiableValueMap mergeProperties, List<String> propertyPaths, String path) {
        boolean isInUse = false;
        for (String propertyPath : propertyPaths) {
            Set<String> set = getPathSet(mergeProperties, propertyPath);
            if (set.contains(path)) {
                isInUse = true;
            }
        }

        return isInUse;
    }


    public static void removeNode(ResourceResolver resourceResolver, ModifiableValueMap mergeProperties, String assetPath, String assetTempPath) {
        logger.info("Attempting to remove node: {}", assetTempPath);

        boolean canDelete = true;
        List<String> propertyPaths = List.of(PROP_ASSET_PATHS, PROP_CONTENT_FRAGMENT_PATHS, PROP_CONTENT_FRAGMENT_MISSING_MODEL_PATHS, PROP_ASSET_METADATA_PATHS);
        for (String propertyPath : propertyPaths) {
            Set<String> set = getPathSet(mergeProperties, propertyPath);
            if (set.contains(assetPath)) {
                canDelete = false;
            }
        }

        if(canDelete) {
            Resource resource = resourceResolver.getResource(assetTempPath);
            if (resource != null) {
                try {
                    Node node = resource.adaptTo(Node.class);
                    Objects.requireNonNull(node).remove();
                } catch (RepositoryException e) {
                    throw new RuntimeException(e);
                }
            }

        } else {
            logger.warn("Cannot delete path, check merge properties: {}", assetPath);
        }

    }

}
