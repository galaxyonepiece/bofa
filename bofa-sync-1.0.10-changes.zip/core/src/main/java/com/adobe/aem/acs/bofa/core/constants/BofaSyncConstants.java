package com.adobe.aem.acs.bofa.core.constants;

public class BofaSyncConstants {

    public final static String BOFA_SYNC_SERVICE_USER = "bofa-sync-service";

    public final static String BOFA_SYNC_WORKFLOW_OPEN = "open";

    public final static String BOFA_SYNC_WORKFLOW_CLOSED = "closed";

    public final static String BOFA_SYNC_CONTENT_FRAGMENT_MERGE_OPEN = "open";

    public final static String BOFA_SYNC_CONTENT_FRAGMENT_MERGE_CLOSED = "closed";

    public final static String BOFA_SYNC_CONTENT_FRAGMENT_MERGE_IGNORE = "ignore";

    public final static String BOFA_SYNC_MERGE_PATH = "/var/merge";

    public final static String BOFA_JCR_NAMESPACE = "spwtaem";

}
