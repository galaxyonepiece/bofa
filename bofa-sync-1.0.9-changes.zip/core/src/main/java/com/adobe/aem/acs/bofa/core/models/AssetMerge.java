package com.adobe.aem.acs.bofa.core.models;

import com.day.cq.dam.api.Asset;

import java.util.ArrayList;
import java.util.List;

public class AssetMerge {

    private AssetMergeMetadata assetMergeMetadata;

    private Asset source;

    private Asset destination;

    private List<AssetDiffField> assetDiffFields;

    private String filename;

    private String mimeType;

    private String mergeStatus;

    private String lastEditedByUsername;

    private boolean inputStreamsEqual;

    public AssetMergeMetadata getAssetMergeMetadata() {
        return assetMergeMetadata;
    }

    public void setAssetMergeMetadata(AssetMergeMetadata assetMergeMetadata) {
        this.assetMergeMetadata = assetMergeMetadata;
    }

    public Asset getSource() {
        return source;
    }

    public void setSource(Asset source) {
        this.source = source;
    }

    public Asset getDestination() {
        return destination;
    }

    public void setDestination(Asset destination) {
        this.destination = destination;
    }

    public List<AssetDiffField> getAssetDiffFields() {
        if(assetDiffFields == null){
            assetDiffFields = new ArrayList<>();
        }
        return assetDiffFields;
    }

    public void setAssetDiffFields(List<AssetDiffField> assetDiffFields) {
        this.assetDiffFields = assetDiffFields;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getMergeStatus() {
        return mergeStatus;
    }

    public void setMergeStatus(String mergeStatus) {
        this.mergeStatus = mergeStatus;
    }

    public String getLastEditedByUsername() {
        return lastEditedByUsername;
    }

    public void setLastEditedByUsername(String lastEditedByUsername) {
        this.lastEditedByUsername = lastEditedByUsername;
    }

    public boolean isInputStreamsEqual() {
        return inputStreamsEqual;
    }

    public void setInputStreamsEqual(boolean inputStreamsEqual) {
        this.inputStreamsEqual = inputStreamsEqual;
    }

}
