package com.adobe.aem.acs.bofa.core.services;

import org.apache.sling.api.resource.ResourceResolver;

public interface MetadataMergeWorkflowService {

    void closeMetadataMerge(ResourceResolver resourceResolver, String assetPath);

}
