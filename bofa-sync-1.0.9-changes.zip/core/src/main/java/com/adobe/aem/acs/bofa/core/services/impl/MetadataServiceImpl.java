package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.models.AssetMergeMetadata;
import com.adobe.aem.acs.bofa.core.models.MetadataMergeMetadata;
import com.adobe.aem.acs.bofa.core.services.MergeConfigService;
import com.adobe.aem.acs.bofa.core.services.MetadataService;
import com.adobe.aem.acs.bofa.core.util.BofaJcrUtils;
import com.day.crx.JcrConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.adobe.aem.acs.bofa.core.constants.BofaJcrPropertyConstants.PROP_ASSET_METADATA_PATHS;

@Component(service =  MetadataService.class, immediate = true)
public class MetadataServiceImpl implements MetadataService {


    private static final Logger logger = LoggerFactory.getLogger(MetadataServiceImpl.class);

    @Reference
    private MergeConfigService mergeConfigService;

    public MetadataMergeMetadata getMetadataMergeMetadata(ResourceResolver resourceResolver, String assetPath) {
        logger.info("Reading assets");
        MetadataMergeMetadata metadataMergeMetadata = null;

        try {
            Node node = resourceResolver.getResource(mergeConfigService.getIncomingMergePath() + assetPath).adaptTo(Node.class);
            metadataMergeMetadata = getMetadataMergeMetadata(node);
        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return metadataMergeMetadata;
    }


    public List<MetadataMergeMetadata> getMetadataMergeMetadataList(ResourceResolver resourceResolver){
        logger.info("Reading assets metadata");

        List<MetadataMergeMetadata> metadataMergeMetadataList = new ArrayList<>();
        try {
            String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
            Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);
            Value[] values = mergeJcrContent.getProperty(BofaJcrUtils.getNamespacedProperty(PROP_ASSET_METADATA_PATHS)).getValues();
            for (Value value : values) {
                String assetPath = value.getString();
                String incomingAssetPath = mergeConfigService.getIncomingMergePath() + assetPath;
                Resource incomingAssetResource = resourceResolver.getResource(incomingAssetPath);
                if (incomingAssetResource == null) {
                    logger.error("Asset path not found: {}", incomingAssetPath);
                } else {
                    Node node = Objects.requireNonNull(incomingAssetResource).adaptTo(Node.class);
                    metadataMergeMetadataList.add(getMetadataMergeMetadata(node));
                }
            }

        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return metadataMergeMetadataList;
    }


    private MetadataMergeMetadata getMetadataMergeMetadata(Node node) throws RepositoryException {

        String nodeName = node.getName();
        String tempPath = StringUtils.removeEnd(node.getPath(), "/" + nodeName);
        String parentPath = StringUtils.removeStart(tempPath, mergeConfigService.getIncomingMergePath());


        MetadataMergeMetadata metadataMergeMetadata = new MetadataMergeMetadata();
        metadataMergeMetadata.setAssetTempPath(node.getPath());
        metadataMergeMetadata.setAssetPath(StringUtils.removeStart(node.getPath(), mergeConfigService.getIncomingMergePath()));
        metadataMergeMetadata.setAssetParentPath(parentPath);
        metadataMergeMetadata.setName(nodeName);


        return metadataMergeMetadata;

    }

}
