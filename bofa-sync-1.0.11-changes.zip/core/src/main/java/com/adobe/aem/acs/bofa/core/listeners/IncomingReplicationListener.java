package com.adobe.aem.acs.bofa.core.listeners;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.executor.JcrResolverExecutor;
import com.adobe.aem.acs.bofa.core.services.*;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.observation.ResourceChange;
import org.apache.sling.api.resource.observation.ResourceChangeListener;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Detects replicated content received into /var on Author instance.
 */
@Component(
        service = ResourceChangeListener.class,
        immediate = true,
        property = {
                ResourceChangeListener.PATHS + "=" + BofaSyncConstants.BOFA_SYNC_MERGE_PATH,
                ResourceChangeListener.CHANGES + "=ADDED",
                ResourceChangeListener.CHANGES + "=CHANGED",
                ResourceChangeListener.PROPERTY_NAMES_HINT + "=cq:lastReplicated"
        }
)
public class IncomingReplicationListener implements ResourceChangeListener {

    private static final Logger logger = LoggerFactory.getLogger(IncomingReplicationListener.class);

    @Reference
    private JcrResolverExecutor executor;

    @Reference
    private MergeConfigService mergeConfigService;

    @Reference
    private ContentFragmentMergeWorkflowService contentFragmentMergeWorkflowService;

    @Reference
    private AssetMergeService assetMergeService;

    @Reference
    private AssetService assetService;

    @Override
    public void onChange(List<ResourceChange> changes) {
        logger.info("Incoming Replication Listener - onChange");

        try {
            executor.runWithWriteAccess((ResourceResolver resourceResolver) -> {

                for (ResourceChange change : changes) {
                    String path = change.getPath();
                    ResourceChange.ChangeType type = change.getType();

                    logger.info("Replicated content change detected path: {}, changeType: {}, mergeTempPath: {}", path, type, mergeConfigService.getIncomingMergePath());
                    if (path.startsWith(mergeConfigService.getIncomingMergePath())) {
                        Resource resource = resourceResolver.getResource(path);
                        if (resource != null) {

                            assetService.checkNode(resourceResolver, path);

                        }
                    }

                }

                logger.info("Starting merge with content fragments");
                contentFragmentMergeWorkflowService.startContentFragmentMerge(resourceResolver);

                logger.info("Starting merge with assets");
                assetMergeService.startAssetMerge(resourceResolver);

                return null;
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
