package com.adobe.aem.acs.bofa.core.models;

public class MetadataDiffField {

    private String name;

    private String title;

    private String source;

    private String destination;

    private String javaDiffUtilDiff;

    private int javaDiffUtilAdditions;

    private int javaDiffUtilDeletions;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getJavaDiffUtilDiff() {
        return javaDiffUtilDiff;
    }

    public void setJavaDiffUtilDiff(String javaDiffUtilDiff) {
        this.javaDiffUtilDiff = javaDiffUtilDiff;
    }

    public int getJavaDiffUtilAdditions() {
        return javaDiffUtilAdditions;
    }

    public void setJavaDiffUtilAdditions(int javaDiffUtilAdditions) {
        this.javaDiffUtilAdditions = javaDiffUtilAdditions;
    }

    public int getJavaDiffUtilDeletions() {
        return javaDiffUtilDeletions;
    }

    public void setJavaDiffUtilDeletions(int javaDiffUtilDeletions) {
        this.javaDiffUtilDeletions = javaDiffUtilDeletions;
    }
}
