package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.models.*;
import com.adobe.aem.acs.bofa.core.services.AssetMergeService;
import com.adobe.aem.acs.bofa.core.services.AssetMergeWorkflowService;
import com.adobe.aem.acs.bofa.core.services.AssetService;
import com.adobe.aem.acs.bofa.core.util.BofaJcrUtils;
import com.day.crx.JcrConstants;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

@Component(service = AssetMergeWorkflowService.class, immediate = true)
public class AssetMergeWorkflowServiceImpl implements AssetMergeWorkflowService {


    private static final Logger logger = LoggerFactory.getLogger(AssetMergeWorkflowServiceImpl.class);

    @Reference
    private AssetService assetService;

    @Reference
    private AssetMergeService assetMergeService;

    public void closeAssetMerge(ResourceResolver resourceResolver, String assetPath){
        logger.debug("Closing Asset Merge assetPath: {}", assetPath);

        AssetMergeMetadata assetMergeMetadata = assetService.getAssetMergeMetadata(resourceResolver, assetPath);

        String assetJcrContentPath = assetMergeMetadata.getAssetTempPath() + "/" + JcrConstants.JCR_CONTENT;
        ModifiableValueMap assetJcrContent = Objects.requireNonNull(resourceResolver.getResource(assetJcrContentPath)).adaptTo(ModifiableValueMap.class);

        AssetMerge assetMerge = assetMergeService.getAssetMerge(resourceResolver, assetMergeMetadata);

        if(assetMerge.isInputStreamsEqual()){
            logger.info("Close asset merge for asset: {}", assetMergeMetadata.getAssetPath());
            assetJcrContent.put(BofaJcrUtils.getNamespacedProperty("mergeStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_CLOSED);
        } else {
            throw new IllegalStateException("Cannot close asset merge, content is not the same");
        }


    }

}
