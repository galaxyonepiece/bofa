package com.adobe.aem.acs.bofa.core.constants;

public class BofaJcrPropertyConstants {

    public static final String PROP_ASSET_PATHS = "assetPaths";

    public static final String PROP_CONTENT_FRAGMENT_PATHS = "contentFragmentPaths";

    public static final String PROP_INCOMING_ASSET_PATHS = "incomingAssetPaths";

    public static final String PROP_INCOMING_CONTENT_FRAGMENT_PATHS = "incomingContentFragmentPaths";

    public static final String PROP_CONTENT_FRAGMENT_MISSING_MODEL_PATHS = "contentFragmentMissingModelPaths";

    public static final String PROP_ASSET_METADATA_PATHS = "assetMetadataPaths";


}
