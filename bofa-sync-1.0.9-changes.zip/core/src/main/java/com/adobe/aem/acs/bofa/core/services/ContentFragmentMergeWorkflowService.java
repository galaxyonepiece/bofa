package com.adobe.aem.acs.bofa.core.services;

import com.adobe.aem.acs.bofa.core.models.ContentFragmentInfo;
import org.apache.sling.api.resource.ResourceResolver;

import java.util.List;

public interface ContentFragmentMergeWorkflowService {

    List<ContentFragmentInfo> startContentFragmentMerge(ResourceResolver resourceResolver);

    void addContentFragmentMissingModel(ResourceResolver resourceResolver, ContentFragmentInfo contentFragmentInfo);

    void removeContentFragmentMissingModel(ResourceResolver resourceResolver, ContentFragmentInfo contentFragmentInfo);

    void closeContentFragmentMerge(ResourceResolver resourceResolver, String contentFragmentPath, String variationName);

    void endContentFragmentMerge(ResourceResolver resourceResolver);

}
