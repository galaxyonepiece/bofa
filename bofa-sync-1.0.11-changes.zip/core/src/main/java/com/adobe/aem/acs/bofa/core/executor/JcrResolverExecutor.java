
package com.adobe.aem.acs.bofa.core.executor;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.Map;

/**
 * High-level service for managing JCR sessions with retry-safe commit and rollback handling.
 */
@Component(service = JcrResolverExecutor.class)
public class JcrResolverExecutor {

    private static final Logger logger = LoggerFactory.getLogger(JcrResolverExecutor.class);
    private static final String DEFAULT_SUBSERVICE = BofaSyncConstants.BOFA_SYNC_SERVICE_USER;
    private static final int MAX_RETRIES = 3;

    @Reference
    private ResourceResolverFactory resolverFactory;

    public <T> T runWithWriteAccess(JcrWork<T> work) throws Exception {
        return runWithWriteAccess(work, DEFAULT_SUBSERVICE);
    }

    public <T> T runWithWriteAccess(JcrWork<T> work, String subserviceName) throws Exception {
        Map<String, Object> authInfo = Collections.singletonMap(
                ResourceResolverFactory.SUBSERVICE, subserviceName);

        for (int attempt = 0; attempt < MAX_RETRIES; attempt++) {
            try (ResourceResolver resolver = resolverFactory.getServiceResourceResolver(authInfo)) {

                T result = work.execute(resolver);

                if (resolver.hasChanges()) {
                    resolver.commit();
                    logger.info("  JCR changes committed on attempt {}", attempt);
                }

                return result;

            } catch (LoginException e) {
                logger.error("Could not obtain service resolver: {}", e.getMessage(), e);
            } catch (PersistenceException e) {
                // Wait or backoff can be added here
                logger.warn("  Commit failed on attempt {}: {}", attempt, e.getMessage());
            }
        }
        throw new PersistenceException("JCR commit failed after " + MAX_RETRIES + " attempts");
    }

    public <T> T runReadOnly(JcrWork<T> work) throws Exception {
        return runReadOnly(work, DEFAULT_SUBSERVICE);
    }

    public <T> T runReadOnly(JcrWork<T> work, String subserviceName) throws Exception {
        Map<String, Object> authInfo = Collections.singletonMap(
                ResourceResolverFactory.SUBSERVICE, subserviceName);

        try (ResourceResolver resolver = resolverFactory.getServiceResourceResolver(authInfo)) {
            return work.execute(resolver);

        } catch (Exception e) {
            logger.error("Error in JCR unit of work (read-only)", e);
            throw e;
        }
    }
}
