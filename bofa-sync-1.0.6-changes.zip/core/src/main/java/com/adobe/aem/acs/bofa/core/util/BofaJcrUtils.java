package com.adobe.aem.acs.bofa.core.util;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;

public class BofaJcrUtils {

    public static String getNamespacedProperty(String property) {
        return String.format("%s:%s", BofaSyncConstants.BOFA_JCR_NAMESPACE, property);
    }

}
