package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.constants.AssetType;
import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.models.MetadataMerge;
import com.adobe.aem.acs.bofa.core.models.MetadataMergeMetadata;
import com.adobe.aem.acs.bofa.core.services.MetadataMergeService;
import com.adobe.aem.acs.bofa.core.services.MetadataMergeWorkflowService;
import com.adobe.aem.acs.bofa.core.services.MetadataService;
import com.adobe.aem.acs.bofa.core.util.BofaJcrUtils;
import com.day.crx.JcrConstants;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

import static com.adobe.aem.acs.bofa.core.constants.BofaJcrPropertyConstants.*;

@Component(service = MetadataMergeWorkflowService.class, immediate = true)
public class MetadataMergeWorkflowServiceImpl implements MetadataMergeWorkflowService {


    private static final Logger logger = LoggerFactory.getLogger(MetadataMergeWorkflowServiceImpl.class);

    @Reference
    private MetadataService metadataService;

    @Reference
    private MetadataMergeService metadataMergeService;

    public void closeMetadataMerge(ResourceResolver resourceResolver, String assetPath){
        logger.debug("Closing Metadata Merge assetPath: {}", assetPath);

        MetadataMergeMetadata metadataMergeMetadata = metadataService.getMetadataMergeMetadata(resourceResolver, assetPath);

        String assetJcrContentPath = metadataMergeMetadata.getAssetTempPath() + "/" + JcrConstants.JCR_CONTENT;
        ModifiableValueMap assetJcrContent = Objects.requireNonNull(resourceResolver.getResource(assetJcrContentPath)).adaptTo(ModifiableValueMap.class);

        MetadataMerge metadataMerge = metadataMergeService.getMetadataMerge(resourceResolver, metadataMergeMetadata);

        logger.info("Close asset merge for asset: {}", metadataMergeMetadata.getAssetPath());
        assetJcrContent.put(BofaJcrUtils.getNamespacedProperty("mergeMetadataStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_CLOSED);


        String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
        ModifiableValueMap mergeProperties = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(ModifiableValueMap.class);

        BofaJcrUtils.removePathFromProperty(mergeProperties, metadataMergeMetadata.getAssetPath(), PROP_ASSET_METADATA_PATHS);

        if (metadataMergeMetadata.getAssetType() == AssetType.ASSET){
            if (!BofaJcrUtils.isAssetInUse(mergeProperties, metadataMergeMetadata.getAssetPath())){
                BofaJcrUtils.removeNode(resourceResolver, mergeProperties, metadataMergeMetadata.getAssetPath(), metadataMergeMetadata.getAssetTempPath());
            }
        } else if (metadataMergeMetadata.getAssetType() == AssetType.CONTENT_FRAGMENT) {
            if (!BofaJcrUtils.isContentFragmentInUse(mergeProperties, metadataMergeMetadata.getAssetPath())){
                BofaJcrUtils.removeNode(resourceResolver, mergeProperties, metadataMergeMetadata.getAssetPath(), metadataMergeMetadata.getAssetTempPath());
            }
        }

    }


}
