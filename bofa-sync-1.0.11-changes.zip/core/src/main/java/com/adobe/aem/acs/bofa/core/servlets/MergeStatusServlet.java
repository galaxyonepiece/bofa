package com.adobe.aem.acs.bofa.core.servlets;

import com.adobe.aem.acs.bofa.core.services.MergeStatusService;
import com.google.gson.Gson;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Component(service = Servlet.class, property = {Constants.SERVICE_DESCRIPTION + "= Merge status servlet",
        "sling.servlet.paths=" + "/bin/mergeStatus", "sling.servlet.methods=" + HttpConstants.METHOD_GET
})
public class MergeStatusServlet extends SlingSafeMethodsServlet {


    private static final Logger logger = LoggerFactory.getLogger(MergeStatusServlet.class);

    @Reference
    private MergeStatusService mergeStatusService;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        logger.info("Getting merge status");

        Gson gson = new Gson();

        try {
            Map<String, List<String>> mergeStatus = mergeStatusService.getMergeStatus();

            gson.toJson(mergeStatus, response.getWriter());

        } catch (Exception e) {
            response.setStatus(500);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"success\": false}");
            throw new RuntimeException(e);
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

    }

}
