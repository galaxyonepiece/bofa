package com.adobe.aem.acs.bofa.core.servlets;

import com.adobe.aem.acs.bofa.core.executor.JcrResolverExecutor;
import com.adobe.aem.acs.bofa.core.models.ContentFragmentInfo;
import com.adobe.aem.acs.bofa.core.services.ContentFragmentMergeWorkflowService;
import com.adobe.aem.acs.bofa.core.services.ContentFragmentService;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import java.io.IOException;
import java.util.List;

@Component(service = Servlet.class, property = {Constants.SERVICE_DESCRIPTION + "= Reprocess Content Fragment with Missing Model",
        "sling.servlet.paths=" + "/bin/reprocessMissingModel", "sling.servlet.methods=" + HttpConstants.METHOD_GET
})
public class ReprocessMissingModelServlet  extends SlingSafeMethodsServlet {


    private static final Logger logger = LoggerFactory.getLogger(ReprocessMissingModelServlet.class);

    @Reference
    JcrResolverExecutor executor;

    @Reference
    private ContentFragmentService contentFragmentService;

    @Reference
    private ContentFragmentMergeWorkflowService contentFragmentMergeWorkflowService;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        logger.info("Reprocess Content Fragment with Missing Model");
        String contentFragmentPath = request.getParameter("contentFragmentPath");
        String contentFragmentTempPath = request.getParameter("contentFragmentTempPath");

        try {
            executor.runWithWriteAccess((ResourceResolver resourceResolver) -> {
//                contentFragmentMergeWorkflowService.endContentFragmentMerge(resourceResolver);
                logger.info("Reprocess Content Fragment with Missing Model: {}", contentFragmentTempPath);
                ContentFragmentInfo contentFragmentInfo = contentFragmentService.checkNode(resourceResolver, contentFragmentTempPath);
                if (contentFragmentInfo != null && !contentFragmentInfo.isMissingContentFragmentModel()) {
                    contentFragmentMergeWorkflowService.removeContentFragmentMissingModel(resourceResolver, contentFragmentInfo);
//                    contentFragmentMergeWorkflowService.startContentFragmentMerge(resourceResolver, List.of(contentFragmentInfo));
                }

                return null;
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }



        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write("{\"success\": true}");

    }

}
