package com.adobe.aem.acs.bofa.core.services;

import java.util.List;
import java.util.Map;

public interface MergeStatusService {

    Map<String, List<String>> getMergeStatus();

}
