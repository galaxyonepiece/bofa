package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.models.*;
import com.adobe.aem.acs.bofa.core.services.*;
import com.adobe.aem.acs.bofa.core.util.BofaAssetUtils;
import com.adobe.aem.acs.bofa.core.util.BofaJcrUtils;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.AssetManager;
import com.day.crx.JcrConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.*;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.RepositoryException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.adobe.aem.acs.bofa.core.constants.BofaJcrPropertyConstants.*;

@Component(service = AssetMergeService.class, immediate = true)
public class AssetMergeServiceImpl implements AssetMergeService {

    private static final Logger logger = LoggerFactory.getLogger(AssetMergeServiceImpl.class);

    @Reference
    private ContentFragmentService contentFragmentService;

    @Reference
    private AssetService assetService;

    @Reference
    private AssetMergeWorkflowService assetMergeWorkflowService;

    @Reference
    private MergeConfigService mergeConfigService;

    @Reference
    private MetadataService metadataService;

    @Reference
    private MetadataMergeService metadataMergeService;


    public List<AssetMergeMetadata> startAssetMerge(ResourceResolver resourceResolver){
        logger.debug("Starting Asset merge workflow");

        List<AssetMergeMetadata> assetMergeMetadataList = new ArrayList<>();

        String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;

        ModifiableValueMap properties = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(ModifiableValueMap.class);
        String[] incomingAssetPathsArr = properties.get(BofaJcrUtils.getNamespacedProperty(PROP_INCOMING_ASSET_PATHS), new String[0]);
        List<String> incomingAssetPaths = Arrays.asList(incomingAssetPathsArr);
        logger.info("Incoming Asset paths: " + StringUtils.join(incomingAssetPaths, ","));


        for (String incomingAssetPath : incomingAssetPaths) {
            assetMergeMetadataList.add(assetService.getAssetMergeMetadata(resourceResolver, incomingAssetPath));
        }


        List<String> current = Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty(PROP_ASSET_PATHS), new String[0]));
        logger.info("Existing Asset paths: {}", StringUtils.join(current, ","));
        Set<String> existingAssetSet = new HashSet<>(current);

        List<String> currentMetadataPaths = Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty(PROP_ASSET_METADATA_PATHS), new String[0]));
        logger.info("Existing Asset Metadata paths: {}", StringUtils.join(currentMetadataPaths, ","));
        Set<String> existingAssetMetadataSet = new HashSet<>(currentMetadataPaths);


        for(AssetMergeMetadata assetMergeMetadata : assetMergeMetadataList){
            logger.info("starting with assetMergeMetadata: {}", assetMergeMetadata.getAssetPath());

            ModifiableValueMap incomingAssetNodeJcrContent = Objects.requireNonNull(resourceResolver.getResource(assetMergeMetadata.getAssetTempPath() + "/" + JcrConstants.JCR_CONTENT)).adaptTo(ModifiableValueMap.class);

            Asset source = Objects.requireNonNull(Objects.requireNonNull(resourceResolver.getResource(assetMergeMetadata.getAssetTempPath())).adaptTo(Asset.class));
            Resource destinationAssetResource = resourceResolver.getResource(assetMergeMetadata.getAssetPath());

            boolean isNewAsset;

            if(destinationAssetResource == null) {
                isNewAsset = true;
                assetService.createAssetFromSource(resourceResolver, source, assetMergeMetadata.getAssetPath());

            } else {
                logger.info("Updating asset: {}", assetMergeMetadata.getAssetPath());
                isNewAsset = false;

                Asset destination = destinationAssetResource.adaptTo(Asset.class);
                String sourceSha1 = BofaAssetUtils.getSha1(source);
                String destinationSha1 = BofaAssetUtils.getSha1(destination);
                logger.info("sourceSha1: {} destinationSha1: {}", sourceSha1, destinationSha1);

                boolean hasMergeConflicts = !StringUtils.equals(sourceSha1, destinationSha1);


                if(hasMergeConflicts){
                    incomingAssetNodeJcrContent.put(BofaJcrUtils.getNamespacedProperty("mergeStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_OPEN);

                    ModifiableValueMap assetMetadata = Objects.requireNonNull(resourceResolver.getResource(assetMergeMetadata.getAssetPath() + "/" + JcrConstants.JCR_CONTENT + "/" + "metadata")).adaptTo(ModifiableValueMap.class);
                    logger.info("Asset hasMergeConflicts: {}", hasMergeConflicts);
                    assetMetadata.put(BofaJcrUtils.getNamespacedProperty("hasMergeConflict"), hasMergeConflicts);


                    // add the new path to list of assets with merge conflicts
                    existingAssetSet.add(assetMergeMetadata.getAssetPath());
                }
                incomingAssetNodeJcrContent.put(BofaJcrUtils.getNamespacedProperty("sha1"), sourceSha1);


            }
            MetadataMerge metadataMerge = metadataMergeService.getMetadataMerge(resourceResolver, getMetadataMergeMetadata(assetMergeMetadata));
            logger.info("metadataMerge isContentIdentical: {}", metadataMerge);
            if(!metadataMerge.isContentIdentical()){
                existingAssetMetadataSet.add(assetMergeMetadata.getAssetPath());
                incomingAssetNodeJcrContent.put(BofaJcrUtils.getNamespacedProperty("mergeMetadataStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_OPEN);

            }

            if(isNewAsset && metadataMerge.isContentIdentical()){
                assetMergeWorkflowService.closeAssetMerge(resourceResolver, assetMergeMetadata.getAssetPath());
            }



            List<String> tempIncomingAssetPaths = new ArrayList<>(Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty(PROP_INCOMING_ASSET_PATHS), new String[0])));
            tempIncomingAssetPaths.remove(assetMergeMetadata.getAssetPath());
            if(tempIncomingAssetPaths.isEmpty()){
                properties.replace(BofaJcrUtils.getNamespacedProperty(PROP_INCOMING_ASSET_PATHS), new String[0]);
            } else {
                properties.put(BofaJcrUtils.getNamespacedProperty(PROP_INCOMING_ASSET_PATHS), tempIncomingAssetPaths);
            }

        }

        List<String> updatedAssetPaths = new ArrayList<>(existingAssetSet);
        logger.info("Updated asset paths: {}", StringUtils.join(updatedAssetPaths, ","));

        properties.put(BofaJcrUtils.getNamespacedProperty(PROP_ASSET_PATHS), updatedAssetPaths.toArray(new String[0]));
//            logger.info("contentFragmentPaths: {}", StringUtils.join(contentFragmentPaths, ", "));

        List<String> updatedMetadataPaths = new ArrayList<>(existingAssetMetadataSet);
        logger.info("Updated metadata paths: {}", StringUtils.join(updatedMetadataPaths, ","));
        properties.put(BofaJcrUtils.getNamespacedProperty(PROP_ASSET_METADATA_PATHS), updatedMetadataPaths.toArray(new String[0]));


        return assetMergeMetadataList;
    }


    public AssetMerge getAssetMerge(ResourceResolver resourceResolver, AssetMergeMetadata assetMergeMetadata) {
        logger.info("Getting content fragment merge");

        AssetMerge assetMerge = null;

        try {

            assetMerge = getAssetMerge(assetMergeMetadata, resourceResolver);


            // calculate if CF can be auto merged
            //setDiffNumbers(assetMerge);

        } catch (LoginException e) {
            logger.error("Error getting content fragment for display", e);
            throw new RuntimeException(e);
        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return assetMerge;

    }

    public List<AssetMerge> getAssetMergeList(ResourceResolver resourceResolver, List<AssetMergeMetadata> assetMergeMetadataList){
        logger.info("Getting content fragment merge list");

        List<AssetMerge> assetMergeList = new ArrayList<>();

        try {
            for (AssetMergeMetadata assetMergeMetadata : assetMergeMetadataList) {

                AssetMerge contentFragmentMerge = getAssetMerge(assetMergeMetadata, resourceResolver);
                assetMergeList.add(contentFragmentMerge);
            }


            // calculate if CF can be auto merged
//            for(ContentFragmentMerge cfMerge : contentFragmentMergeList){
//                setDiffNumbers(cfMerge);
//            }


        } catch (LoginException e) {
            logger.error("Error getting content fragment for display", e);
            throw new RuntimeException(e);
        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return assetMergeList;
    }

    private AssetMerge getAssetMerge(AssetMergeMetadata assetMergeMetadata, ResourceResolver resourceResolver) throws LoginException, RepositoryException {

        Asset source = Objects.requireNonNull(resourceResolver.getResource(assetMergeMetadata.getAssetTempPath())).adaptTo(Asset.class);
        logger.info("Asset: {}", source.getPath());

        ValueMap sourceNodeJcrContent = Objects.requireNonNull(resourceResolver.getResource(assetMergeMetadata.getAssetTempPath() + "/" + JcrConstants.JCR_CONTENT)).adaptTo(ValueMap.class);

        Asset destination = null;
        Resource destinationResouce = resourceResolver.getResource(assetMergeMetadata.getAssetPath());
        if(destinationResouce == null){
            logger.error("Destination resource not found: {}", assetMergeMetadata.getAssetPath());
        } else {
            destination = Objects.requireNonNull(destinationResouce).adaptTo(Asset.class);
        }

        String mergeStatus = sourceNodeJcrContent.get(BofaJcrUtils.getNamespacedProperty("mergeStatus"), "N/A");
        String sourceSha1 = sourceNodeJcrContent.get(BofaJcrUtils.getNamespacedProperty("sha1"), "");
        String destinationSha1;
        if(destinationResouce == null){
            destinationSha1 = "";
        } else {
            destinationSha1 = BofaAssetUtils.getSha1(destination);
        }

        AssetMerge assetMerge = new AssetMerge();
        assetMerge.setSource(source);
        assetMerge.setDestination(destination);
        assetMerge.setAssetMergeMetadata(assetMergeMetadata);
        assetMerge.setMergeStatus(mergeStatus);
        assetMerge.setFilename(source.getName());
        assetMerge.setMimeType(source.getMimeType());
        assetMerge.setInputStreamsEqual(StringUtils.equals(sourceSha1, destinationSha1));

        List<AssetDiffField> assetDiffFields = new ArrayList<>();
        AssetDiffField sha1 = new AssetDiffField();
        sha1.setName("sha1");
        sha1.setTitle("SHA-1");
        sha1.setSourceValue(sourceSha1);
        sha1.setDestinationValue(destinationSha1);


        AssetDiffField dateLastModifiedField = new AssetDiffField();
        dateLastModifiedField.setName("dateLastModified");
        dateLastModifiedField.setTitle("Date Last Modified");
        dateLastModifiedField.setSourceValue(getLastModifiedDate(resourceResolver, source));
        dateLastModifiedField.setDestinationValue(getLastModifiedDate(resourceResolver, destination));

        assetDiffFields.add(sha1);
        assetDiffFields.add(dateLastModifiedField);


        // TODO: use source or destination for user for email notification
        assetMerge.setLastEditedByUsername(sourceNodeJcrContent.get("jcr:lastModifiedBy", ""));

        assetMerge.setAssetDiffFields(assetDiffFields);

        return assetMerge;
    }

    private MetadataMergeMetadata getMetadataMergeMetadata(AssetMergeMetadata assetMergeMetadata) {
        MetadataMergeMetadata metadataMergeMetadata = new MetadataMergeMetadata();
        metadataMergeMetadata.setName(assetMergeMetadata.getName());
        metadataMergeMetadata.setTitle(assetMergeMetadata.getTitle());
        metadataMergeMetadata.setAssetPath(assetMergeMetadata.getAssetPath());
        metadataMergeMetadata.setAssetTempPath(assetMergeMetadata.getAssetTempPath());
        metadataMergeMetadata.setAssetParentPath(assetMergeMetadata.getAssetParentPath());

        return metadataMergeMetadata;
    }

    private String getLastModifiedDate(ResourceResolver resourceResolver, Asset asset) {
        if(asset == null){
            return "N/A";
        }
        Resource assetResource = resourceResolver.getResource(asset.getPath());
        Resource originalResource = Objects.requireNonNull(assetResource).getChild("jcr:content/renditions/original/jcr:content");

        String lastModifiedString = "";
        if (originalResource != null) {
            ValueMap vm = originalResource.getValueMap();
            Date lastModified = vm.get("jcr:lastModified", Date.class);
            if (lastModified != null) {

                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                lastModifiedString = formatter.format(lastModified);
                logger.info("Original binary last modified: {}, formatted: {}", lastModified.getTime(), lastModifiedString);


            }
        }

        return lastModifiedString;
    }



}
