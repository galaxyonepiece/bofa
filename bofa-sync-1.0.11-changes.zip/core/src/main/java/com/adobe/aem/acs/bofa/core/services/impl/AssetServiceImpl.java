package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.models.AssetMergeMetadata;
import com.adobe.aem.acs.bofa.core.models.ContentFragmentInfo;
import com.adobe.aem.acs.bofa.core.services.AssetService;
import com.adobe.aem.acs.bofa.core.services.ContentFragmentMergeWorkflowService;
import com.adobe.aem.acs.bofa.core.services.ContentFragmentService;
import com.adobe.aem.acs.bofa.core.services.MergeConfigService;
import com.adobe.aem.acs.bofa.core.util.BofaJcrUtils;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.AssetManager;
import com.day.crx.JcrConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.*;
import java.io.InputStream;
import java.util.*;

import static com.adobe.aem.acs.bofa.core.constants.BofaJcrPropertyConstants.*;

@Component(service = AssetService.class,  immediate = true)
public class AssetServiceImpl implements AssetService {


    private static final Logger logger = LoggerFactory.getLogger(AssetServiceImpl.class);

    @Reference
    private ContentFragmentService contentFragmentService;

    @Reference
    private ContentFragmentMergeWorkflowService contentFragmentMergeWorkflowService;

    @Reference
    private MergeConfigService mergeConfigService;

    public void checkNode(ResourceResolver resourceResolver, String path){
        logger.info("checkNode: {}", path);

        if(StringUtils.endsWith(path, JcrConstants.JCR_CONTENT)){
            ValueMap jcrValueMap = resourceResolver.getResource(path).adaptTo(ValueMap.class);
            if(jcrValueMap != null){
                if(jcrValueMap.containsKey(JcrConstants.JCR_PRIMARYTYPE)){
                    String jcrPrimaryType = jcrValueMap.get(JcrConstants.JCR_PRIMARYTYPE, String.class);
                    if(StringUtils.equals(jcrPrimaryType, "dam:AssetContent")){
                        path = StringUtils.removeEnd(path, "/" + JcrConstants.JCR_CONTENT);
                        logger.info("checkNode updated path: {}", path);
                    }
                }
            }
        }

        Resource resource = Objects.requireNonNull(resourceResolver.getResource(path));
        Asset asset = resource.adaptTo(Asset.class);
        try {
            if (asset != null) {
                // it's an asset
                logger.info("Asset checking path: {}",  asset.getPath());

                ContentFragmentInfo incomingContentFragment = contentFragmentService.checkNode(resourceResolver, path);
                if(incomingContentFragment == null) {
                    // the asset is not a content fragment
                    logger.info("Asset found: {}, {}", asset.getMimeType(), asset.getPath());

                    addIncomingPath(resourceResolver, path, false);

                } else {
                    // the asset is a content fragment
                    if(incomingContentFragment.isMissingContentFragmentModel()) {
                        contentFragmentMergeWorkflowService.addContentFragmentMissingModel(resourceResolver, incomingContentFragment);
                    } else {
    //                    incomingContentFragments.add(incomingContentFragment);
    //                    contentFragmentMergeWorkflowService.startContentFragmentMerge(resourceResolver, List.of(incomingContentFragment));
                            addIncomingPath(resourceResolver, path, true);
                    }
                }

            }
        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }



    }


    public AssetMergeMetadata getAssetMergeMetadata(ResourceResolver resourceResolver, String assetPath) {
        logger.info("Reading assets");
        AssetMergeMetadata assetMergeMetadata = null;

        try {
            Node node = resourceResolver.getResource(mergeConfigService.getIncomingMergePath() + "/" + assetPath).adaptTo(Node.class);
            assetMergeMetadata = getAssetMergeMetadata(node);
        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return assetMergeMetadata;
    }


    public List<AssetMergeMetadata> getAssetMergeMetadataList(ResourceResolver resourceResolver){
        logger.info("Reading assets");

        List<AssetMergeMetadata> assetMergeMetadataList = new ArrayList<>();
        try {
            String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
            Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);
            Value[] values = mergeJcrContent.getProperty(BofaJcrUtils.getNamespacedProperty(PROP_ASSET_PATHS)).getValues();
            for (Value value : values) {
                String assetPath = value.getString();
                String incomingAssetPath = mergeConfigService.getIncomingMergePath() + "/" + assetPath;
                Resource incomingAssetResource = resourceResolver.getResource(incomingAssetPath);
                if (incomingAssetResource == null) {
                    logger.error("Asset path not found: {}", incomingAssetPath);
                } else {
                    Node node = Objects.requireNonNull(incomingAssetResource).adaptTo(Node.class);
                    assetMergeMetadataList.add(getAssetMergeMetadata(node));
                }
            }

        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return assetMergeMetadataList;
    }


    public Asset createAssetFromSource(ResourceResolver resourceResolver, Asset source, String assetPath){
        logger.info("Creating new asset: {}", assetPath);

        AssetManager assetManager = resourceResolver.adaptTo(AssetManager.class);

        InputStream sourceStream = source.getOriginal().getStream();

        Asset asset = Objects.requireNonNull(assetManager).createAsset(assetPath, sourceStream, source.getMimeType(), false);

        return asset;
    }


    public Asset updateAssetFromSource(ResourceResolver resourceResolver, String assetPath){

        logger.info("Updating asset from source: {}", assetPath);

        try {
            Node node = Objects.requireNonNull(resourceResolver.getResource(mergeConfigService.getIncomingMergePath() + "/" + assetPath)).adaptTo(Node.class);
            AssetMergeMetadata assetMergeMetadata = getAssetMergeMetadata(Objects.requireNonNull(node));

            Asset source = Objects.requireNonNull(resourceResolver.getResource(assetMergeMetadata.getAssetTempPath())).adaptTo(Asset.class);

            AssetManager assetManager = resourceResolver.adaptTo(AssetManager.class);

            InputStream sourceStream = Objects.requireNonNull(source).getOriginal().getStream();
            Session session = resourceResolver.adaptTo(Session.class);
            ValueFactory valueFactory = Objects.requireNonNull(session).getValueFactory();
            Binary binary = valueFactory.createBinary(sourceStream);

            Asset asset = Objects.requireNonNull(assetManager).createOrUpdateAsset(assetPath, binary, source.getMimeType(), false);

            return asset;


        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }



    }



    private void addIncomingPath(ResourceResolver resourceResolver, String path, boolean isContentFragment) throws RepositoryException {

        String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
        Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);

        String propertyKey = isContentFragment ? PROP_INCOMING_CONTENT_FRAGMENT_PATHS : PROP_INCOMING_ASSET_PATHS;

        ModifiableValueMap properties = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(ModifiableValueMap.class);
        List<String> current = new ArrayList<>(Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty(propertyKey), new String[0])));

        Set<String> pathSet = new HashSet<>(current);
        String damPath = StringUtils.removeStart(path, mergeConfigService.getIncomingMergePath());
        pathSet.add(damPath);

        List<String> assetPaths = new ArrayList<>(pathSet);

        mergeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty(propertyKey), assetPaths.toArray(new String[0]));
        logger.info("New {} paths: {}", propertyKey, StringUtils.join(assetPaths, ","));


    }


    private AssetMergeMetadata getAssetMergeMetadata(Node node) throws RepositoryException {

        String nodeName = node.getName();
        String tempPath = StringUtils.removeEnd(node.getPath(), "/" + nodeName);
        String parentPath = StringUtils.removeStart(tempPath, mergeConfigService.getIncomingMergePath());


        AssetMergeMetadata assetMergeMetadata = new AssetMergeMetadata();
        assetMergeMetadata.setAssetTempPath(node.getPath());
        assetMergeMetadata.setAssetPath(StringUtils.removeStart(node.getPath(), mergeConfigService.getIncomingMergePath()));
        assetMergeMetadata.setAssetParentPath(parentPath);
        assetMergeMetadata.setName(nodeName);


        return assetMergeMetadata;

    }


}
