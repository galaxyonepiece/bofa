package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.models.TagData;
import com.adobe.aem.acs.bofa.core.models.TagDiff;
import com.adobe.aem.acs.bofa.core.services.TagService;
import com.adobe.cq.dam.cfm.ContentFragment;
import com.adobe.cq.dam.cfm.ContentFragmentException;
import com.day.cq.dam.api.Asset;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

@Component(service = TagService.class, immediate = true)
public class TagServiceImpl implements TagService {


    private static final Logger logger = LoggerFactory.getLogger(TagServiceImpl.class);

    private static final String MASTER = "master";


    public TagDiff getTags(ResourceResolver resourceResolver, Asset source, Asset destination) {

        List<Tag> sourceTags = getAssetTags(resourceResolver, source);
        List<Tag> destinationTags = getAssetTags(resourceResolver, destination);

        TagDiff tagDiff = new TagDiff();
        extracted(sourceTags, destinationTags, tagDiff);

        return tagDiff;
    }




    public TagDiff getTags(ResourceResolver resourceResolver, String variationName,
                           ContentFragment source, ContentFragment destination){

        logger.debug("Getting tags for {}", variationName);

        TagDiff tagDiff = new TagDiff();

        try {
            Tag[] sourceTagsArr;
            Tag[] destinationTagsArr;
            if (variationName.equals(MASTER)) {
                sourceTagsArr = source.getTags();
                destinationTagsArr = destination.getTags();
            } else {
                sourceTagsArr = source.getVariationTags(variationName);
                destinationTagsArr = destination.getVariationTags(variationName);
            }
            logger.info("sourceTagsArr: {}", sourceTagsArr.length);
            for (Tag tag : sourceTagsArr) {
                logger.info("source tag: {}", tag.getName());
            }

            logger.info("destinationTagsArr: {}", destinationTagsArr.length);
            for (Tag tag : destinationTagsArr) {
                logger.info("destination tag: {}", tag.getName());
            }

            List<Tag> sourceTags = Arrays.stream(Objects.requireNonNull(sourceTagsArr))
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
            List<Tag> destinationTags = Arrays.stream(Objects.requireNonNull(destinationTagsArr))
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());


            extracted(sourceTags, destinationTags, tagDiff);

        } catch (ContentFragmentException e) {
            throw new RuntimeException(e);
        }

        return tagDiff;
    }

    private void extracted(List<Tag> sourceTags, List<Tag> destinationTags, TagDiff tagDiff) {
        List<Tag> onlySource = sourceTags.stream()
                .filter(element -> !destinationTags.contains(element))
                .collect(Collectors.toList());

        List<Tag> onlyDestination = destinationTags.stream()
                .filter(element -> !sourceTags.contains(element))
                .collect(Collectors.toList());


        List<Tag> common = sourceTags.stream()
                .filter(destinationTags::contains)
                .collect(Collectors.toList());

        logger.info("onlySource: {}", onlySource.size());
        logger.info("onlyDestination: {}", onlyDestination.size());
        logger.info("common: {}", common.size());

        tagDiff.setSourceTags(convertTagList(sourceTags));
        tagDiff.setDestinationTags(convertTagList(destinationTags));
        tagDiff.setAddedTags(convertTagList(onlySource));
        tagDiff.setRemovedTags(convertTagList(onlyDestination));
        tagDiff.setCommonTags(convertTagList(common));
    }

    private List<TagData> convertTagList(List<Tag> tags){
        List<TagData> tagDataList = new ArrayList<>();
        for (Tag tag : tags) {
            TagData tagData = new TagData();
            tagData.setTitle(tag.getTitle());
            tagData.setTagId(tag.getTagID());
            tagData.setName(tag.getName());

            tagDataList.add(tagData);
        }

        return tagDataList;
    }


    private List<Tag> getAssetTags(ResourceResolver resourceResolver, Asset asset) {
        if (asset == null) {
            return Collections.emptyList();
        }

        TagManager tagManager = resourceResolver.adaptTo(TagManager.class);

        List<Tag> tags = new ArrayList<>();

        Resource metadataRes = Objects.requireNonNull(resourceResolver.getResource(asset.getPath())).getChild("jcr:content/metadata");
        if(metadataRes != null) {
            ValueMap vm = metadataRes.getValueMap();
            String[] tagIds = vm.get("cq:tags", String[].class);

            if (tagIds == null) {
                return Collections.emptyList();
            }


            for (String tagId : tagIds) {
                Tag tag = Objects.requireNonNull(tagManager).resolve(tagId);
                if (tag != null) {
                    tags.add(tag);
                }
            }
        }

        return tags;
    }

}
