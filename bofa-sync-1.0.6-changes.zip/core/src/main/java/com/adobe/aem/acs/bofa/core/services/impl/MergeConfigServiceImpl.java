package com.adobe.aem.acs.bofa.core.services.impl;


import com.adobe.aem.acs.bofa.core.config.BofaMergeConfig;
import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.executor.JcrResolverExecutor;
import com.adobe.aem.acs.bofa.core.services.MergeConfigService;
import org.apache.jackrabbit.commons.JcrUtils;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import java.util.Objects;

@Component(service = MergeConfigService.class, immediate = true)
@Designate(ocd = BofaMergeConfig.class)
public class MergeConfigServiceImpl implements MergeConfigService {

    private static final Logger logger = LoggerFactory.getLogger(MergeConfigServiceImpl.class);

    private String incomingChangesFolder;

    private String outgoingChangesFolder;

    @Reference
    private JcrResolverExecutor executor;

    @Activate
    @Modified
    protected void activate(BofaMergeConfig bofaMergeConfig) {
        this.incomingChangesFolder = bofaMergeConfig.incomingChangesFolder();
        this.outgoingChangesFolder = bofaMergeConfig.outgoingChangesFolder();

        logger.info("Setting incomingChangesFolder: {}, outgoingChangesFolder: {}", incomingChangesFolder, outgoingChangesFolder);

        try {
            executor.runWithWriteAccess(resourceResolver -> {
                Node mergeNode = Objects.requireNonNull(resourceResolver.getResource(BofaSyncConstants.BOFA_SYNC_MERGE_PATH)).adaptTo(Node.class);
                assert mergeNode != null;

                JcrUtils.getOrAddFolder(mergeNode, incomingChangesFolder);
                JcrUtils.getOrAddFolder(mergeNode, outgoingChangesFolder);
                return null;
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }


    public String getIncomingMergePath(){
        String path = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + incomingChangesFolder;
//        logger.debug("Incoming Merge Path: {}", path);
        return path;
    }

    public String getOutgoingMergePath(){
        String path = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + outgoingChangesFolder;
//        logger.debug("Outgoing Merge Path: {}", path);
        return path;
    }


}
