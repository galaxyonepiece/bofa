package com.adobe.aem.acs.bofa.core.services;

import com.adobe.aem.acs.bofa.core.models.ContentFragmentDiffField;
import com.adobe.aem.acs.bofa.core.models.MetadataDiffField;

public interface JavaDiffUtilDiffService {

    void diff(ContentFragmentDiffField contentFragmentDiffField);

    void diff(MetadataDiffField metadataDiffField);

}
