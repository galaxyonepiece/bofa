package com.adobe.aem.acs.bofa.core.services;

import com.adobe.aem.acs.bofa.core.models.MetadataMerge;
import com.adobe.aem.acs.bofa.core.models.MetadataMergeMetadata;
import org.apache.sling.api.resource.ResourceResolver;

import java.util.List;

public interface MetadataMergeService {

    MetadataMerge getMetadataMerge(ResourceResolver resourceResolver, MetadataMergeMetadata metadataMergeMetadata);

    List<MetadataMerge> getMetadataMergeList(ResourceResolver resourceResolver, List<MetadataMergeMetadata> metadataMergeMetadataList);
}
