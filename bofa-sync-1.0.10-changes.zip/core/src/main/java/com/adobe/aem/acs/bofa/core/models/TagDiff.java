package com.adobe.aem.acs.bofa.core.models;

import java.util.ArrayList;
import java.util.List;

public class TagDiff {

    private List<TagData> sourceTags;

    private List<TagData> destinationTags;

    private List<TagData> addedTags;

    private List<TagData> removedTags;

    private List<TagData> commonTags;

    public List<TagData> getSourceTags() {
        if (sourceTags == null) {
            sourceTags = new ArrayList<>();
        }
        return sourceTags;
    }

    public void setSourceTags(List<TagData> sourceTags) {
        this.sourceTags = sourceTags;
    }

    public List<TagData> getDestinationTags() {
        if (destinationTags == null) {
            destinationTags = new ArrayList<>();
        }
        return destinationTags;
    }

    public void setDestinationTags(List<TagData> destinationTags) {
        this.destinationTags = destinationTags;
    }

    public List<TagData> getAddedTags() {
        if (addedTags == null) {
            addedTags = new ArrayList<>();
        }
        return addedTags;
    }

    public void setAddedTags(List<TagData> addedTags) {
        this.addedTags = addedTags;
    }

    public List<TagData> getRemovedTags() {
        if (removedTags == null) {
            removedTags = new ArrayList<>();
        }
        return removedTags;
    }

    public void setRemovedTags(List<TagData> removedTags) {
        this.removedTags = removedTags;
    }

    public List<TagData> getCommonTags() {
        if (commonTags == null) {
            commonTags = new ArrayList<>();
        }
        return commonTags;
    }

    public void setCommonTags(List<TagData> commonTags) {
        this.commonTags = commonTags;
    }
}
