package com.adobe.aem.acs.bofa.core.models;

import com.adobe.aem.acs.bofa.core.constants.AssetType;

public class MetadataMergeMetadata {
    private String assetPath;

    private String assetTempPath;

    private String assetParentPath;

    private String name;

    private String title;

    private AssetType assetType;

    public String getAssetPath() {
        return assetPath;
    }

    public void setAssetPath(String assetPath) {
        this.assetPath = assetPath;
    }

    public String getAssetTempPath() {
        return assetTempPath;
    }

    public void setAssetTempPath(String assetTempPath) {
        this.assetTempPath = assetTempPath;
    }

    public String getAssetParentPath() {
        return assetParentPath;
    }

    public void setAssetParentPath(String assetParentPath) {
        this.assetParentPath = assetParentPath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public AssetType getAssetType() {
        return assetType;
    }

    public void setAssetType(AssetType assetType) {
        this.assetType = assetType;
    }
}
