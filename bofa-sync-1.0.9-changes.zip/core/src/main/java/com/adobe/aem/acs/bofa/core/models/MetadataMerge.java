package com.adobe.aem.acs.bofa.core.models;

import com.day.cq.dam.api.Asset;

import java.util.List;

public class MetadataMerge {

    private MetadataMergeMetadata metadataMergeMetadata;

    private Asset source;

    private Asset destination;

    private List<MetadataDiffField> metadataDiffFields;

    private String filename;

    private String mimeType;

    private boolean autoMerge;

    private boolean contentIdentical;

    private String mergeStatus;

    private String lastEditedByUsername;

    public MetadataMergeMetadata getMetadataMergeMetadata() {
        return metadataMergeMetadata;
    }

    public void setMetadataMergeMetadata(MetadataMergeMetadata metadataMergeMetadata) {
        this.metadataMergeMetadata = metadataMergeMetadata;
    }

    public Asset getSource() {
        return source;
    }

    public void setSource(Asset source) {
        this.source = source;
    }

    public Asset getDestination() {
        return destination;
    }

    public void setDestination(Asset destination) {
        this.destination = destination;
    }

    public List<MetadataDiffField> getMetadataDiffFields() {
        return metadataDiffFields;
    }

    public void setMetadataDiffFields(List<MetadataDiffField> metadataDiffFields) {
        this.metadataDiffFields = metadataDiffFields;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public boolean isAutoMerge() {
        return autoMerge;
    }

    public void setAutoMerge(boolean autoMerge) {
        this.autoMerge = autoMerge;
    }

    public boolean isContentIdentical() {
        return contentIdentical;
    }

    public void setContentIdentical(boolean contentIdentical) {
        this.contentIdentical = contentIdentical;
    }

    public String getMergeStatus() {
        return mergeStatus;
    }

    public void setMergeStatus(String mergeStatus) {
        this.mergeStatus = mergeStatus;
    }

    public String getLastEditedByUsername() {
        return lastEditedByUsername;
    }

    public void setLastEditedByUsername(String lastEditedByUsername) {
        this.lastEditedByUsername = lastEditedByUsername;
    }
}
