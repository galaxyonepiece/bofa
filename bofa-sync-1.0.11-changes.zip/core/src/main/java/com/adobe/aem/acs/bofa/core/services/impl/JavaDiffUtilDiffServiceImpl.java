package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.models.ContentFragmentDiffField;
import com.adobe.aem.acs.bofa.core.models.MetadataDiffField;
import com.adobe.aem.acs.bofa.core.services.JavaDiffUtilDiffService;
import com.github.difflib.text.DiffRow;
import com.github.difflib.text.DiffRowGenerator;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@Component(service = {JavaDiffUtilDiffService.class}, immediate = true)
public class JavaDiffUtilDiffServiceImpl implements JavaDiffUtilDiffService {

    private static final Logger logger = LoggerFactory.getLogger(JavaDiffUtilDiffServiceImpl.class);

    public void diff(ContentFragmentDiffField contentFragmentDiffField) {

        //create a configured DiffRowGenerator
        DiffRowGenerator generator = DiffRowGenerator.create()
                .showInlineDiffs(true)
                .mergeOriginalRevised(true)
                .inlineDiffByWord(true)
                .oldTag(f -> "~")      //introduce markdown style for strikethrough
                .newTag(f -> "**")     //introduce markdown style for bold
                .build();

        //compute the differences for two test texts.

//        List<DiffRow> rows = generator.generateDiffRows(
//                Arrays.asList("This is a test senctence."),
//                Arrays.asList("This is a test for diffutils."));
//        logger.info(rows.get(0).getOldLine());

        String source = contentFragmentDiffField.getSource();
        String destination = contentFragmentDiffField.getDestination();

        if(contentFragmentDiffField.getContentType().equals("text/html")){
            if(StringUtils.endsWith(source, "</p>")) {
                source = replacePTag(source);
            }
            if(StringUtils.endsWith(destination, "</p>")) {
                destination = replacePTag(destination);
            }
        }


        List<DiffRow> rows = generator.generateDiffRows(
                List.of(destination.replace("\n", "^^").replace("</", "%%").replace("<", "&&").replace(">", "||")),
                List.of(source.replace("\n", "^^").replace("</", "%%").replace("<", "&&").replace(">", "||")));
        logger.info("oldLine: {}", rows.get(0).getOldLine());
        logger.info("newLine: {}", rows.get(0).getNewLine());
//        String result = rows.get(0).getOldLine().replace("&lt;", "<").replace("&gt;", ">").replace("^^", "\n");
        String result = rows.get(0).getOldLine().replace("&&", "<").replace("||", ">").replace("%%", "</").replace("^^", "\n");
        int additions = StringUtils.countMatches(result, "**");
        int deletions = StringUtils.countMatches(result, "~");
        result = replaceMarkdown(result, "**", "ins");
        result = replaceMarkdown(result, "~", "del");

        if(contentFragmentDiffField.getContentType().equals("text/html")){
            if(StringUtils.endsWith(source, "</p>")) {
                result = String.format("<p>%s</p>", result);
            }
        }


        logger.debug("Diff from java-diff-util: {}", result);
        logger.debug("java-diff-util additions: {}", additions);
        logger.debug("java-diff-util deletions: {}", deletions);

        contentFragmentDiffField.setJavaDiffUtilDiff(result);
        contentFragmentDiffField.setJavaDiffUtilAdditions(additions);
        contentFragmentDiffField.setJavaDiffUtilDeletions(deletions);


    }


    public void diff(MetadataDiffField metadataDiffField) {

        //create a configured DiffRowGenerator
        DiffRowGenerator generator = DiffRowGenerator.create()
                .showInlineDiffs(true)
                .mergeOriginalRevised(true)
                .inlineDiffByWord(true)
                .oldTag(f -> "~")      //introduce markdown style for strikethrough
                .newTag(f -> "**")     //introduce markdown style for bold
                .build();

        String source = metadataDiffField.getSource();
        String destination = metadataDiffField.getDestination();


        List<DiffRow> rows = generator.generateDiffRows(
                List.of(destination),
                List.of(source));
        logger.info("oldLine: {}", rows.get(0).getOldLine());
        logger.info("newLine: {}", rows.get(0).getNewLine());
//        String result = rows.get(0).getOldLine().replace("&lt;", "<").replace("&gt;", ">").replace("^^", "\n");
        String result = rows.get(0).getOldLine();
        int additions = StringUtils.countMatches(result, "**");
        int deletions = StringUtils.countMatches(result, "~");
        result = replaceMarkdown(result, "**", "ins");
        result = replaceMarkdown(result, "~", "del");


        logger.debug("Diff from java-diff-util: {}", result);
        logger.debug("java-diff-util additions: {}", additions);
        logger.debug("java-diff-util deletions: {}", deletions);

        metadataDiffField.setJavaDiffUtilDiff(result);
        metadataDiffField.setJavaDiffUtilAdditions(additions);
        metadataDiffField.setJavaDiffUtilDeletions(deletions);


    }


    private static String replacePTag(String html){
        logger.info("replacePTag start: {}", html);

        html = StringUtils.replaceOnce(html, "<p>", "");
        int i = StringUtils.lastIndexOf(html, "</p>");
        html = StringUtils.substring(html, 0, i);

        logger.info("replacePTag i: {} end: {}", i, html);

        return html;
    }


    private static String replaceMarkdown(String text, String target, String replacement) {
        int counter = 0;
        int index = text.indexOf(target);
        StringBuilder result = new StringBuilder();
        int prevIndex = 0;

        while (index != -1) {
            logger.debug("prevIndex: {}, index: {}", prevIndex, index);
            if (counter % 2 == 0) {
                result.append(text, prevIndex, index);
                result.append("<");
                result.append(replacement);
                result.append(">");
                prevIndex = index + target.length();
                logger.debug("prevIndex: {}", prevIndex);
                logger.debug(result.toString());
            } else {
                result.append(text, prevIndex, index)
                        .append("</").append(replacement).append(">");
                prevIndex = index + target.length();
            }
            counter++;
            index = text.indexOf(target, index + target.length());
        }
        result.append(text, prevIndex, text.length());
        return result.toString();
    }
}
