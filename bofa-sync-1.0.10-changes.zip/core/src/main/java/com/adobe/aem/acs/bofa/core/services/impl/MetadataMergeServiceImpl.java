package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.constants.AssetType;
import com.adobe.aem.acs.bofa.core.models.*;
import com.adobe.aem.acs.bofa.core.services.JavaDiffUtilDiffService;
import com.adobe.aem.acs.bofa.core.services.MergeConfigService;
import com.adobe.aem.acs.bofa.core.services.MetadataMergeService;
import com.adobe.aem.acs.bofa.core.services.TagService;
import com.adobe.aem.acs.bofa.core.util.BofaJcrUtils;
import com.day.cq.dam.api.Asset;
import com.day.crx.JcrConstants;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component(service = MetadataMergeService.class, immediate = true)
public class MetadataMergeServiceImpl implements MetadataMergeService {

    private static final Logger logger = LoggerFactory.getLogger(MetadataMergeServiceImpl.class);

    @Reference
    private MergeConfigService mergeConfigService;

    @Reference
    private JavaDiffUtilDiffService javaDiffUtilDiffService;

    @Reference
    private TagService tagService;


    public MetadataMerge getMetadataMerge(ResourceResolver resourceResolver, MetadataMergeMetadata metadataMergeMetadata) {
        logger.info("Getting asset metadata merge");

        MetadataMerge metadataMerge = null;

        try {

            metadataMerge = getMetadataMerge(metadataMergeMetadata, resourceResolver);


            // calculate if CF can be auto merged
            setDiffNumbers(metadataMerge);

        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return metadataMerge;

    }

    public List<MetadataMerge> getMetadataMergeList(ResourceResolver resourceResolver, List<MetadataMergeMetadata> metadataMergeMetadataList){
        logger.info("Getting metadata merge merge list");

        List<MetadataMerge> metadataMergeList = new ArrayList<>();

        try {
            for (MetadataMergeMetadata metadataMergeMetadata : metadataMergeMetadataList) {

                MetadataMerge contentFragmentMerge = getMetadataMerge(metadataMergeMetadata, resourceResolver);
                metadataMergeList.add(contentFragmentMerge);
            }


            // calculate if CF can be auto merged
            for(MetadataMerge metadataMerge : metadataMergeList){
                setDiffNumbers(metadataMerge);
            }


        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return metadataMergeList;
    }


    private MetadataMerge getMetadataMerge(MetadataMergeMetadata metadataMergeMetadata, ResourceResolver resourceResolver) throws RepositoryException {

        Asset source = Objects.requireNonNull(resourceResolver.getResource(metadataMergeMetadata.getAssetTempPath())).adaptTo(Asset.class);
        logger.info("Metadata: {}", source.getPath());

        ValueMap sourceNodeJcrContent = Objects.requireNonNull(resourceResolver.getResource(metadataMergeMetadata.getAssetTempPath() + "/" + JcrConstants.JCR_CONTENT)).adaptTo(ValueMap.class);

        Asset destination = null;
        Resource destinationResouce = resourceResolver.getResource(metadataMergeMetadata.getAssetPath());
        if(destinationResouce == null){
            logger.error("Destination resource not found: {}", metadataMergeMetadata.getAssetPath());
            return null;
        } else {
            destination = Objects.requireNonNull(destinationResouce).adaptTo(Asset.class);
        }



//        ContentFragment destination = resourceResolver.getResource(contentFragmentInfo.getContentFragmentPath()).adaptTo(ContentFragment.class);
//        ValueMap destinationNodeJcrContent = resourceResolver.getResource(assetMergeMetadata.getAssetPath() + "/" + JcrConstants.JCR_CONTENT).adaptTo(ValueMap.class);
        // logger.info("Asset {}", source.toString());

        String mergeStatus = sourceNodeJcrContent.get(BofaJcrUtils.getNamespacedProperty("mergeMetadataStatus"), "N/A");

        MetadataMerge metadataMerge = new MetadataMerge();
        metadataMerge.setSource(source);
        metadataMerge.setDestination(destination);
        metadataMerge.setMetadataMergeMetadata(metadataMergeMetadata);
        metadataMerge.setMergeStatus(mergeStatus);
        metadataMerge.setFilename(source.getName());
        metadataMerge.setMimeType(source.getMimeType());


        String listPath = mergeConfigService.getMetadataListPath() + "/" + JcrConstants.JCR_CONTENT + "/" + "list";
        Resource listResource = resourceResolver.getResource(mergeConfigService.getMetadataListPath());
        Resource listContentResource = resourceResolver.getResource(mergeConfigService.getMetadataListPath() + "/" + JcrConstants.JCR_CONTENT);
        Resource listListResource = resourceResolver.getResource(listPath);
        logger.info("Using list path: {}", listPath);

        if(listResource == null || listContentResource == null || listListResource == null){
            throw new RuntimeException("ListResource or listContentResource or listListResource not found in JCR");
        }

        Node listNode = listListResource.adaptTo(Node.class);
        NodeIterator nodes = listNode.getNodes();

        boolean tagsInList = false;

        List<MetadataDiffField> metadataDiffFields = new ArrayList<>();
        while (nodes.hasNext()) {
            Node listItemNode = (Node) nodes.next();


            // list key/values are stored in the properties jcr:title/value
            if(listItemNode.hasProperty("jcr:title") && listItemNode.hasProperty("value")){
                String listItemTitle = listItemNode.getProperty("jcr:title").getString();
                String listItemValue = listItemNode.getProperty("value").getString();
                logger.info("Found list item [{}: {}]", listItemTitle, listItemValue);

                if(StringUtils.equals(listItemValue, "cq:tags")) {
                    tagsInList = true;
                } else {
                    String sourceValue = source.getMetadataValue(listItemValue);
                    String destinationValue = destination.getMetadataValue(listItemValue);
                    logger.info("Got metadata values source: [{}] destination: [{}]", sourceValue, destinationValue);

                    if (sourceValue == null) {
                        sourceValue = "";
                    }
                    if (destinationValue == null) {
                        destinationValue = "";
                    }

                    MetadataDiffField metadataDiffField = new MetadataDiffField();
                    metadataDiffField.setTitle(listItemTitle);
                    metadataDiffField.setName(listItemValue);
                    metadataDiffField.setSource(sourceValue);
                    metadataDiffField.setDestination(destinationValue);

                    javaDiffUtilDiffService.diff(metadataDiffField);

                    metadataDiffFields.add(metadataDiffField);
                }

            }
            metadataMerge.setMetadataDiffFields(metadataDiffFields);



        }

        // TODO asset tags
        if(tagsInList && metadataMergeMetadata.getAssetType() == AssetType.ASSET) {
            logger.info("Found tags in list, TODO");
            TagDiff tagDiff = tagService.getTags(resourceResolver, source, destination);
            metadataMerge.setTagDiff(tagDiff);
        }

        // TODO: use source or destination for user for email notification
        metadataMerge.setLastEditedByUsername(sourceNodeJcrContent.get("jcr:lastModifiedBy", ""));

        return metadataMerge;
    }


    private static void setDiffNumbers(MetadataMerge metadataMerge) {
        int additions = 0;
        int deletions = 0;

        for(MetadataDiffField field : metadataMerge.getMetadataDiffFields()){
            additions += field.getJavaDiffUtilAdditions();
            deletions += field.getJavaDiffUtilDeletions();
        }

        metadataMerge.setAutoMerge(additions == 0 || deletions == 0);
        metadataMerge.setContentIdentical(additions == 0 && deletions == 0);


    }


}
