package com.adobe.aem.acs.bofa.core.models;

public class ContentFragmentInfo {

    private String contentFragmentPath;

    private String contentFragmentTempPath;

    private String contentFragmentParentPath;

    private String name;

    private String title;

    private String modelPath;

    private boolean missingContentFragmentModel;

    public String getContentFragmentPath() {
        return contentFragmentPath;
    }

    public void setContentFragmentPath(String contentFragmentPath) {
        this.contentFragmentPath = contentFragmentPath;
    }

    public String getContentFragmentTempPath() {
        return contentFragmentTempPath;
    }

    public void setContentFragmentTempPath(String contentFragmentTempPath) {
        this.contentFragmentTempPath = contentFragmentTempPath;
    }

    public String getContentFragmentParentPath() {
        return contentFragmentParentPath;
    }

    public void setContentFragmentParentPath(String contentFragmentParentPath) {
        this.contentFragmentParentPath = contentFragmentParentPath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getModelPath() {
        return modelPath;
    }

    public void setModelPath(String modelPath) {
        this.modelPath = modelPath;
    }

    public boolean isMissingContentFragmentModel() {
        return missingContentFragmentModel;
    }

    public void setMissingContentFragmentModel(boolean missingContentFragmentModel) {
        this.missingContentFragmentModel = missingContentFragmentModel;
    }
}
