package com.adobe.aem.acs.bofa.core.servlets;

import com.adobe.aem.acs.bofa.core.executor.JcrResolverExecutor;
import com.adobe.aem.acs.bofa.core.services.ContentFragmentMergeWorkflowService;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import java.io.IOException;

@Component(service = Servlet.class, property = {Constants.SERVICE_DESCRIPTION + "= Close Content Fragment Variation Merge",
        "sling.servlet.paths=" + "/bin/closeContentFragmentMerge", "sling.servlet.methods=" + HttpConstants.METHOD_GET
})
public class CloseContentMergeServlet extends SlingSafeMethodsServlet {

    private static final Logger logger = LoggerFactory.getLogger(CloseContentMergeServlet.class);

    @Reference
    JcrResolverExecutor executor;

    @Reference
    private ContentFragmentMergeWorkflowService contentFragmentMergeWorkflowService;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        String contentFragmentPath = request.getParameter("contentFragmentPath");
        String variationName = request.getParameter("variationName");
        logger.info("Close merge for content fragment: {}", contentFragmentPath);

        try {
            executor.runWithWriteAccess((ResourceResolver resourceResolver) -> {
                contentFragmentMergeWorkflowService.closeContentFragmentVariationMerge(resourceResolver, contentFragmentPath, variationName);
                return null;
            });
        } catch (Exception e) {
            response.setStatus(500);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"success\": false}");
            throw new RuntimeException(e);
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write("{\"success\": true}");

    }


}
