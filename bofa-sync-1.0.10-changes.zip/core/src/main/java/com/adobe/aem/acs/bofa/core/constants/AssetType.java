package com.adobe.aem.acs.bofa.core.constants;

public enum AssetType {

    CONTENT_FRAGMENT("content_fragment"),
    ASSET("asset");


    private final String type;

    AssetType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }


}
