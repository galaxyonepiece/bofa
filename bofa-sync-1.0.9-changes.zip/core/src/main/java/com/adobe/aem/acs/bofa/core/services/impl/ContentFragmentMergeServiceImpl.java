package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.models.*;
import com.adobe.aem.acs.bofa.core.services.ContentFragmentMergeService;
import com.adobe.aem.acs.bofa.core.services.ContentFragmentService;
import com.adobe.aem.acs.bofa.core.services.JavaDiffUtilDiffService;
import com.adobe.aem.acs.bofa.core.util.BofaJcrUtils;
import com.adobe.cq.dam.cfm.*;
import com.day.crx.JcrConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.*;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import java.util.*;

@Component(service = {ContentFragmentMergeService.class}, immediate = true)
public class ContentFragmentMergeServiceImpl implements ContentFragmentMergeService {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Reference
    private ContentFragmentManager contentFragmentManager;

    @Reference
    private ContentFragmentService contentFragmentService;

    @Reference
    private JavaDiffUtilDiffService javaDiffUtilDiffService;

    private final static String MASTER = "master";


    public ContentFragmentMerge getContentFragmentMerge(ResourceResolver resourceResolver, ContentFragmentInfo contentFragmentInfo) {
        logger.info("Getting content fragment merge");

        ContentFragmentMerge contentFragmentMerge = null;

        try {

            contentFragmentMerge = getContentFragmentMerge(contentFragmentInfo, resourceResolver);


            // calculate if CF can be auto merged
            setDiffNumbers(contentFragmentMerge);

        } catch (LoginException e) {
            logger.error("Error getting content fragment for display", e);
            throw new RuntimeException(e);
        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return contentFragmentMerge;

    }

    public List<ContentFragmentMerge> getContentFragmentMergeList(ResourceResolver resourceResolver, List<ContentFragmentInfo> contentFragmentInfoList){
        logger.info("Getting content fragment merge list");

        List<ContentFragmentMerge> contentFragmentMergeList = new ArrayList<>();

        try {
            for (ContentFragmentInfo contentFragmentInfo : contentFragmentInfoList) {

                ContentFragmentMerge contentFragmentMerge = getContentFragmentMerge(contentFragmentInfo, resourceResolver);
                contentFragmentMergeList.add(contentFragmentMerge);
            }


            // calculate if CF can be auto merged
            for(ContentFragmentMerge cfMerge : contentFragmentMergeList){
                setDiffNumbers(cfMerge);

            }


        } catch (LoginException e) {
            logger.error("Error getting content fragment for display", e);
            throw new RuntimeException(e);
        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return contentFragmentMergeList;
    }

    private ContentFragmentMerge getContentFragmentMerge(ContentFragmentInfo contentFragmentInfo, ResourceResolver resourceResolver) throws LoginException, RepositoryException {

        Session session = resourceResolver.adaptTo(Session.class);
        ContentFragment source = Objects.requireNonNull(resourceResolver.getResource(contentFragmentInfo.getContentFragmentTempPath())).adaptTo(ContentFragment.class);
        logger.info("Content fragment {}", source);

        Node sourceNodeJcrContent = Objects.requireNonNull(resourceResolver.getResource(contentFragmentInfo.getContentFragmentTempPath() + "/" + JcrConstants.JCR_CONTENT)).adaptTo(Node.class);

        ContentFragment destination;
        if(session.nodeExists(contentFragmentInfo.getContentFragmentPath())){
            // use existing CF
            destination = Objects.requireNonNull(resourceResolver.getResource(contentFragmentInfo.getContentFragmentPath())).adaptTo(ContentFragment.class);
        } else {
            // create new CF
            logger.info("Creating content fragment parent path: {}, model: {}, name: {}, title: {}", contentFragmentInfo.getContentFragmentParentPath(),
                    contentFragmentInfo.getModelPath(), contentFragmentInfo.getName(), contentFragmentInfo.getTitle());
            Resource templateResc = resourceResolver.resolve(contentFragmentInfo.getModelPath());
            Resource cfParentResc = resourceResolver.resolve(contentFragmentInfo.getContentFragmentParentPath());

            try {
                FragmentTemplate fragmentTemplate = templateResc.adaptTo(FragmentTemplate.class);
                destination = fragmentTemplate.createFragment(cfParentResc, contentFragmentInfo.getName(), contentFragmentInfo.getTitle());
                if (destination != null) {
                    logger.info("Created CF Title={}", destination.getTitle());
                    logger.info("Created CF name={}", destination.getName());
                }

                List<String> souceVariationNames = new ArrayList<>();
                souceVariationNames.add(MASTER);
                source.listAllVariations().forEachRemaining(variation -> {
                    souceVariationNames.add(variation.getName());
                    try {
                        destination.createVariation(variation.getName(), variation.getTitle(), variation.getTitle());
                    } catch (ContentFragmentException e) {
                        throw new RuntimeException(e);
                    }
                });

                for(String variationName : souceVariationNames){
                    this.autoMerge(resourceResolver, contentFragmentInfo.getContentFragmentPath(), variationName);
                }

            } catch (ContentFragmentException e) {
                logger.error("ContentFragmentException={}", e.getMessage());
                throw new RuntimeException(e);
            }


        }



//        ContentFragment destination = resourceResolver.getResource(contentFragmentInfo.getContentFragmentPath()).adaptTo(ContentFragment.class);
        Node destinationNodeJcrContent = resourceResolver.getResource(contentFragmentInfo.getContentFragmentPath() + "/" + JcrConstants.JCR_CONTENT).adaptTo(Node.class);
        logger.info("Content fragment {}", source.toString());

        String mergeStatus;
        if(sourceNodeJcrContent.hasProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus"))){
            mergeStatus = sourceNodeJcrContent.getProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus")).getString();
        } else {
            mergeStatus = "N/A";
        }

        ContentFragmentMerge contentFragmentMerge = new ContentFragmentMerge();
        contentFragmentMerge.setSource(source);
        contentFragmentMerge.setDestination(destination);
        contentFragmentMerge.setContentFragmentInfo(contentFragmentInfo);
        contentFragmentMerge.setMergeStatus(mergeStatus);

        // TODO: use source or destination for user for email notification
        contentFragmentMerge.setLastEditedByUsername(sourceNodeJcrContent.getProperty("jcr:lastModifiedBy").getString());

        ContentFragmentVariation contentFragmentVariation = new ContentFragmentVariation();
        contentFragmentVariation.setName(MASTER);
        contentFragmentVariation.setTitle("Master");
        contentFragmentMerge.getVariations().add(contentFragmentVariation);

        Node dataNode = sourceNodeJcrContent.getNode("data");
        Node masterNode = dataNode.getNode("master");
        contentFragmentVariation.setMergeStatus(masterNode.getProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus")).getString());

        Iterator<ContentElement> it = source.getElements();
        while(it.hasNext()){
            ContentElement contentElement = it.next();
            String sourceContent = contentElement.getValue().getValue(String.class);
            logger.info("semanticType: {}, valueType: {}, contentType: {}", contentElement.getValue().getDataType().getSemanticType(),
                    contentElement.getValue().getDataType().getValueType(),
                    contentElement.getValue().getContentType());


            ContentFragmentDiffField field = new ContentFragmentDiffField();
            field.setDisplay(contentElement.getTitle());
            field.setName(contentElement.getName());
            field.setSource(sourceContent);
            field.setContentType(contentElement.getContentType());
            field.setSemanticType(contentElement.getValue().getDataType().getSemanticType());

            contentFragmentVariation.getContentFragmentDiffFields().add(field);

        }

        Iterator<VariationDef> variationIterator = source.listAllVariations();
        logger.info("checking variations");
        while (variationIterator.hasNext()) {
            VariationDef variation = variationIterator.next();
            logger.info("    source variation: [{}]", variation.getName());

            ContentFragmentVariation contentFragmentVariation2 = new ContentFragmentVariation();
            contentFragmentVariation2.setName(variation.getName());
            contentFragmentVariation2.setTitle(variation.getTitle());
            contentFragmentMerge.getVariations().add(contentFragmentVariation2);

            Node variationNode = dataNode.getNode(variation.getName());
            contentFragmentVariation2.setMergeStatus(variationNode.getProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus")).getString());

            Iterator<ContentElement> variationIt = source.getElements();
            while (variationIt.hasNext()) {
                ContentElement contentElement = variationIt.next();
                String sourceContent = contentElement.getVariation(variation.getName()).getValue().getValue(String.class);
                logger.info("variation semanticType: {}, valueType: {}, contentType: {}", contentElement.getValue().getDataType().getSemanticType(),
                        contentElement.getValue().getDataType().getValueType(),
                        contentElement.getValue().getContentType());


                ContentFragmentDiffField field = new ContentFragmentDiffField();
                field.setDisplay(contentElement.getTitle());
                field.setName(contentElement.getName());
                field.setSource(sourceContent);
                field.setContentType(contentElement.getContentType());
                field.setSemanticType(contentElement.getValue().getDataType().getSemanticType());

                contentFragmentVariation2.getContentFragmentDiffFields().add(field);


            }
        }

        logger.info("Source list Number of variations: {}", contentFragmentMerge.getVariations().size());
        for(ContentFragmentVariation variation : contentFragmentMerge.getVariations()){
            logger.info("    source variation: {}", variation.getName());
        }


        logger.info("sanity check");
        for(ContentFragmentVariation variation : contentFragmentMerge.getVariations()){
            logger.info("variation: {}", variation.getName());
            for(ContentFragmentDiffField field : variation.getContentFragmentDiffFields()){
                logger.info("    variation: [{}], field: [{}]", variation.getName(), field.getName());
            }

        }

        List<String> destinationVariationNames = new ArrayList<>();
        destinationVariationNames.add(MASTER);

        variationIterator = destination.listAllVariations();
        logger.info("checking variations");
        while (variationIterator.hasNext()) {
            VariationDef variation = variationIterator.next();
            logger.info("    destination variation: {}", variation.getName());
            destinationVariationNames.add(variation.getName());
        }

        logger.info("Destination variation list: {}", StringUtils.join(destinationVariationNames, ", "));

        Iterator<ContentElement> it2 = destination.getElements();
        while(it2.hasNext()){
            ContentElement contentElement = it2.next();
            logger.info("contentElement name: {}", contentElement.getName());
            for(String destinationVariationName : destinationVariationNames){


                if(destinationVariationName.equals(MASTER)){
                    logger.info("variationName: {}, value: {}", destinationVariationName, contentElement.getValue().getValue(String.class));
                } else {
                    logger.info("variationName: {}, value: {}", destinationVariationName, contentElement.getVariation(destinationVariationName).getValue().getValue(String.class));
                }



                for(ContentFragmentVariation sourceFragmentVariation : contentFragmentMerge.getVariations()){
                    logger.info("  loop variables: variationName: [{}], sourceFragmentVariation.getName(): [{}]", destinationVariationName,  sourceFragmentVariation.getName());
                    if(sourceFragmentVariation.getName().equals(destinationVariationName)){
                        logger.info("    loop variation {}", sourceFragmentVariation.getName());
                        sourceFragmentVariation.getContentFragmentDiffFields().stream().filter(f -> f.getName().equals(contentElement.getName())).findFirst().ifPresent(f -> {

                            if(destinationVariationName.equals(MASTER)){
                                String v = contentElement.getValue().getValue(String.class);
                                logger.info("    f.setDestination variationName: {}, value: {}", sourceFragmentVariation.getName(), v);
                                f.setDestination(v);
                            } else {
                                String v = contentElement.getVariation(destinationVariationName).getValue().getValue(String.class);
                                logger.info("    f.setDestination variationName: {}, value: {}", sourceFragmentVariation.getName(), v);
                                f.setDestination(v);
                            }


                        });
                    }
                }

            }

        }


        logger.info("sanity check");
        for(ContentFragmentVariation variation : contentFragmentMerge.getVariations()){
            logger.info("variation: {}", variation.getName());
            for(ContentFragmentDiffField field : variation.getContentFragmentDiffFields()){
                logger.info("    variation: [{}], field: [{}], source: {}, destination: {}", variation.getName(), field.getName(), StringUtils.left(field.getSource(), 20), StringUtils.left(field.getDestination(), 20));
            }

        }


        for(ContentFragmentVariation variation : contentFragmentMerge.getVariations()){
            for(ContentFragmentDiffField diffField : variation.getContentFragmentDiffFields()) {
                javaDiffUtilDiffService.diff(diffField);
                logger.debug("Source Content element: {}, display: {}, contentType: {}, source: [{}], destination: [{}], diff: [{}]",
                        diffField.getName(), diffField.getDisplay(), diffField.getContentType(), diffField.getSource(), diffField.getDestination(), diffField.getJavaDiffUtilDiff());

            }

        }

        return contentFragmentMerge;
    }

    private static void setDiffNumbers(ContentFragmentMerge cfMerge) {
        for(ContentFragmentVariation variation : cfMerge.getVariations()){
            int additions = 0;
            int deletions = 0;

            for(ContentFragmentDiffField field : variation.getContentFragmentDiffFields()){
                additions += field.getJavaDiffUtilAdditions();
                deletions += field.getJavaDiffUtilDeletions();
            }

            variation.setAutoMerge(additions == 0 || deletions == 0);
            variation.setContentIdentical(additions == 0 && deletions == 0);

        }

    }


    public void autoMerge(ResourceResolver resourceResolver, String contentFragmentPath, String variation) {

        logger.info("Auto merge contentFragmentPath: {}",  contentFragmentPath);
        ContentFragmentInfo contentFragmentInfo = contentFragmentService.getContentFragmentInfo(resourceResolver, contentFragmentPath);

        if(contentFragmentInfo == null){
            throw new RuntimeException("Content fragment path not found");
        }

        ContentFragmentMerge contentFragmentMerge = this.getContentFragmentMerge(resourceResolver, contentFragmentInfo);

        ContentFragmentVariation contentFragmentVariation = contentFragmentMerge.getVariation(variation);

        if(contentFragmentVariation.isAutoMerge()) {

            logger.info("Auto merge variation: {}, path: {}", variation, contentFragmentInfo.getContentFragmentPath());


            try {
                ContentFragment source = resourceResolver.getResource(contentFragmentInfo.getContentFragmentTempPath()).adaptTo(ContentFragment.class);
                ContentFragment destination = resourceResolver.resolve(contentFragmentInfo.getContentFragmentPath()).adaptTo(ContentFragment.class);

                logger.info("    autoMerge");

                Map<String, ContentElement> contentElementMap = new HashMap<>();
                Iterator<ContentElement> sourceElements = source.getElements();
                while (sourceElements.hasNext()) {
                    ContentElement contentElement = sourceElements.next();
                    //logger.info("Source Content element: {}, content: {}", contentElement.getName(), contentElement.getValue().getValue()); // contentElement.getVariation(MASTER).getContent());
//                FragmentData fragmentData = contentElement.getVariation(mergeVariation).getValue();
//                contentElement.getVariation(variation).setValue(fragmentData);
                    contentElementMap.put(contentElement.getName(), contentElement);
                }

                Iterator<ContentElement> destinationElements = destination.getElements();
                while (destinationElements.hasNext()) {
                    ContentElement contentElement = destinationElements.next();

                    ContentFragmentDiffField diffField = contentFragmentVariation.getContentFragmentDiffField(contentElement.getName());

                    if(diffField.getJavaDiffUtilAdditions() == 0 && diffField.getJavaDiffUtilDeletions() == 0) {
                        logger.info("    automerge ignoring identical contents for field: {}", contentElement.getName());
                    } else {
                        logger.info("    automerge field: {}", contentElement.getName());

                        ContentElement sourceContentElement = contentElementMap.get(contentElement.getName());
                        if(StringUtils.equals(variation, MASTER)){
                            contentElement.setValue(sourceContentElement.getValue());

                        } else {
                            ContentVariation sourceContentElementVariation = sourceContentElement.getVariation(variation);
                            ContentVariation destinationContentElementVariation = contentElement.getVariation(variation);

                            destinationContentElementVariation.setValue(sourceContentElementVariation.getValue());

                        }
                    }

                }

            } catch (ContentFragmentException e) {
                logger.error("Error updating temp content fragments", e);
                throw new RuntimeException(e);
            }
        } else {
            throw new RuntimeException(String.format("Cannot auto merge variation %s, path %s", variation, contentFragmentPath));
        }

    }


}
