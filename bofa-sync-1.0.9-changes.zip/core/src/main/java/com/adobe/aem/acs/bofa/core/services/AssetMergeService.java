package com.adobe.aem.acs.bofa.core.services;

import com.adobe.aem.acs.bofa.core.models.AssetMerge;
import com.adobe.aem.acs.bofa.core.models.AssetMergeMetadata;
import org.apache.sling.api.resource.ResourceResolver;

import java.util.List;

public interface AssetMergeService {

    AssetMerge getAssetMerge(ResourceResolver resourceResolver, AssetMergeMetadata assetMergeMetadata);

    List<AssetMergeMetadata> startAssetMerge(ResourceResolver resourceResolver);

    List<AssetMerge> getAssetMergeList(ResourceResolver resourceResolver, List<AssetMergeMetadata> assetMergeMetadataList);

}
