package com.adobe.aem.acs.bofa.core.models;

import com.adobe.aem.acs.bofa.core.executor.JcrResolverExecutor;
import com.adobe.aem.acs.bofa.core.services.*;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.*;
import org.apache.sling.models.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.*;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.REQUIRED)
public class ReportCfCompareModel {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private JcrResolverExecutor executor;

    @Inject
    private ContentFragmentService contentFragmentService;

    @Inject
    private ContentFragmentMergeService contentFragmentMergeService;

    @Inject
    private AssetService assetService;

    @Inject
    private AssetMergeService assetMergeService;

    @Inject
    private MetadataService metadataService;

    @Inject
    private MetadataMergeService metadataMergeService;

    @Inject
    private SlingHttpServletRequest request;



    public ContentFragmentMerge getContentFragmentMerge(){
        logger.info("Reading content fragments for merge");
        String contentFragmentPath = request.getParameter("contentFragmentPath");
        String variationName = request.getParameter("variationName");

        ContentFragmentMerge contentFragmentMergeRet = null;
        try {
            contentFragmentMergeRet = executor.runReadOnly((ResourceResolver resourceResolver) -> {
                ContentFragmentInfo contentFragmentInfo = contentFragmentService.getContentFragmentInfo(resourceResolver, contentFragmentPath);

                if(contentFragmentInfo == null){
                    throw new RuntimeException("Content fragment path not found");
                }

                ContentFragmentMerge contentFragmentMerge = contentFragmentMergeService.getContentFragmentMerge(resourceResolver, contentFragmentInfo);

                List<ContentFragmentVariation> list = new ArrayList<>();
                for(ContentFragmentVariation contentFragmentVariation : contentFragmentMerge.getVariations()){
                    logger.info("comparing {}, {}", variationName, contentFragmentVariation.getName());
                    if(contentFragmentVariation.getName().equals(variationName)){
                        list.add(contentFragmentVariation);
                    }
                }
                contentFragmentMerge.setVariations(list);

                for(ContentFragmentVariation contentFragmentVariation : contentFragmentMerge.getVariations()){
                    for(ContentFragmentDiffField field : contentFragmentVariation.getContentFragmentDiffFields()){
                        logger.info("    field: {}, {} {}", field.getName(), field.getSource(), field.getDestination());
                    }
                }

                return contentFragmentMerge;
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


        return contentFragmentMergeRet;
    }


    public AssetMerge getAssetMerge(){
        logger.info("Reading asset for merge");
        String assetPath = request.getParameter("assetPath");

        AssetMerge assetMergeRet = null;
        try {
            assetMergeRet = executor.runReadOnly((ResourceResolver resourceResolver) -> {
                AssetMergeMetadata assetMergeMetadata = assetService.getAssetMergeMetadata(resourceResolver, assetPath);

                if(assetMergeMetadata == null){
                    throw new RuntimeException("Content fragment path not found");
                }

                AssetMerge assetMerge = assetMergeService.getAssetMerge(resourceResolver, assetMergeMetadata);

                return assetMerge;
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


        return assetMergeRet;
    }


    public MetadataMerge getMetadataMerge(){
        logger.info("Reading asset metadata for merge");
        String assetPath = request.getParameter("assetPath");

        MetadataMerge metadataMergeRet = null;
        try {
            metadataMergeRet = executor.runReadOnly((ResourceResolver resourceResolver) -> {
                MetadataMergeMetadata metadataMergeMetadata = metadataService.getMetadataMergeMetadata(resourceResolver, assetPath);

                if(metadataMergeMetadata == null){
                    throw new RuntimeException("Content fragment path not found");
                }

                MetadataMerge metadataMerge = metadataMergeService.getMetadataMerge(resourceResolver, metadataMergeMetadata);

                return metadataMerge;
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


        return metadataMergeRet;
    }


    public List<ContentFragmentMerge> getContentFragmentMergeList(){

        List<ContentFragmentMerge> contentFragmentMergeListRet = new ArrayList<>();

        try {
            contentFragmentMergeListRet = executor.runWithWriteAccess((ResourceResolver resourceResolver) -> {

                logger.info("Reading content fragments, {}", contentFragmentService);
                List<ContentFragmentInfo> contentFragmentInfoList = contentFragmentService.getContentFragmentInfoList(resourceResolver);

                logger.info("contentFragmentMergeService.getContentFragmentForDisplay(contentFragmentInfoList)");
                List<ContentFragmentMerge> contentFragmentMergeList = contentFragmentMergeService.getContentFragmentMergeList(resourceResolver, contentFragmentInfoList);

                for(ContentFragmentMerge contentFragmentMerge : contentFragmentMergeList){
                    for(ContentFragmentVariation contentFragmentVariation : contentFragmentMerge.getVariations()){
                        logger.info("table info: {}, {}, contentIdentical: {}", contentFragmentMerge.getContentFragmentInfo().getTitle(),
                                contentFragmentVariation.getName(),
                                contentFragmentVariation.isContentIdentical());
                    }
                }

                return contentFragmentMergeList;
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }




        return contentFragmentMergeListRet;
    }


    public List<AssetMerge> getAssetMergeList(){

        List<AssetMerge> assetMergeListRet = new ArrayList<>();

        try {
            assetMergeListRet = executor.runWithWriteAccess((ResourceResolver resourceResolver) -> {

                logger.info("Reading content fragments, {}", contentFragmentService);
                List<AssetMergeMetadata> assetMergeMetadataList = assetService.getAssetMergeMetadataList(resourceResolver);

                logger.info("contentFragmentMergeService.getContentFragmentForDisplay(contentFragmentInfoList)");
                List<AssetMerge> assetMergeList = assetMergeService.getAssetMergeList(resourceResolver, assetMergeMetadataList);

//                for(ContentFragmentInfo assetMerge : assetMergeList){
//                    for(ContentFragmentVariation contentFragmentVariation : contentFragmentMerge.getVariations()){
//                        logger.info("table info: {}, {}, contentIdentical: {}", contentFragmentMerge.getContentFragmentInfo().getTitle(),
//                                contentFragmentVariation.getName(),
//                                contentFragmentVariation.isContentIdentical());
//                    }
//                }

                return assetMergeList;
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }




        return assetMergeListRet;
    }


    public List<MetadataMerge> getMetadataMergeList(){

        List<MetadataMerge> assetMergeListRet = new ArrayList<>();

        try {
            assetMergeListRet = executor.runWithWriteAccess((ResourceResolver resourceResolver) -> {

                logger.info("Reading asset metadata for merge");
                List<MetadataMergeMetadata> metadataMergeMetadataList = metadataService.getMetadataMergeMetadataList(resourceResolver);

                logger.info("contentFragmentMergeService.getContentFragmentForDisplay(contentFragmentInfoList)");
                List<MetadataMerge> assetMergeList = metadataMergeService.getMetadataMergeList(resourceResolver, metadataMergeMetadataList);

//                for(ContentFragmentInfo assetMerge : assetMergeList){
//                    for(ContentFragmentVariation contentFragmentVariation : contentFragmentMerge.getVariations()){
//                        logger.info("table info: {}, {}, contentIdentical: {}", contentFragmentMerge.getContentFragmentInfo().getTitle(),
//                                contentFragmentVariation.getName(),
//                                contentFragmentVariation.isContentIdentical());
//                    }
//                }

                return assetMergeList;
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }




        return assetMergeListRet;
    }


    public List<ContentFragmentInfo> getContentFragmentMergeMissingModelList(){
        List<ContentFragmentInfo> contentFragmentInfoListRet = new ArrayList<>();

        try {
            contentFragmentInfoListRet = executor.runWithWriteAccess((ResourceResolver resourceResolver) -> {

                logger.info("Reading content fragments missing model");

                List<ContentFragmentInfo> contentFragmentsMissingModel = contentFragmentService.getContentFragmentsMissingModel(resourceResolver);
                for(ContentFragmentInfo contentFragmentInfo : contentFragmentsMissingModel){
                    logger.info("Missing model: {}, path: {}, modelPath: {}", contentFragmentInfo.getTitle(), contentFragmentInfo.getContentFragmentPath(), contentFragmentInfo.getModelPath());
                }
                return contentFragmentsMissingModel;
            });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return contentFragmentInfoListRet;
    }

}
