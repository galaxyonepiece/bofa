package com.adobe.aem.acs.bofa.core.services;

import com.adobe.aem.acs.bofa.core.models.ContentFragmentInfo;
import org.apache.sling.api.resource.ResourceResolver;

import java.util.List;

//@ProviderType
public interface ContentFragmentService {

    ContentFragmentInfo getContentFragmentInfo(ResourceResolver resourceResolver, String contentFragmentPath);

    List<ContentFragmentInfo> getContentFragmentInfoList(ResourceResolver resourceResolver);

    List<ContentFragmentInfo> getContentFragmentsMissingModel(ResourceResolver resourceResolver);

    List<ContentFragmentInfo> getContentFragmentsInTempPath(ResourceResolver resourceResolver, String tempPath);

    ContentFragmentInfo checkNode(ResourceResolver resourceResolver, String path);
}
