package com.adobe.aem.acs.bofa.core.services;

public interface MergeConfigService {

    String getIncomingMergePath();

    String getOutgoingMergePath();

    String getMetadataListPath();

}
