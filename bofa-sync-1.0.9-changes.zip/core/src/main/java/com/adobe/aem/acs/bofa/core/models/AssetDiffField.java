package com.adobe.aem.acs.bofa.core.models;

public class AssetDiffField {

    private String name;

    private String title;

    private String sourceValue;

    private String destinationValue;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSourceValue() {
        return sourceValue;
    }

    public void setSourceValue(String sourceValue) {
        this.sourceValue = sourceValue;
    }

    public String getDestinationValue() {
        return destinationValue;
    }

    public void setDestinationValue(String destinationValue) {
        this.destinationValue = destinationValue;
    }

    public boolean areValuesEqual() {
        return sourceValue.equals(destinationValue);
    }

}
