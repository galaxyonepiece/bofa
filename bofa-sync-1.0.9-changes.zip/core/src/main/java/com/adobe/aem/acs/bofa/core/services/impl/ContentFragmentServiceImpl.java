package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.models.ContentFragmentInfo;
import com.adobe.aem.acs.bofa.core.services.ContentFragmentService;
import com.adobe.aem.acs.bofa.core.services.MergeConfigService;
import com.adobe.aem.acs.bofa.core.util.BofaJcrUtils;
import com.day.crx.JcrConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.*;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.*;
import java.util.*;

import static com.adobe.aem.acs.bofa.core.constants.BofaJcrPropertyConstants.PROP_CONTENT_FRAGMENT_MISSING_MODEL_PATHS;
import static com.adobe.aem.acs.bofa.core.constants.BofaJcrPropertyConstants.PROP_CONTENT_FRAGMENT_PATHS;

@Component(service = {ContentFragmentService.class}, immediate = true)
public class ContentFragmentServiceImpl implements ContentFragmentService {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Reference
    private MergeConfigService mergeConfigService;

    public ContentFragmentInfo getContentFragmentInfo(ResourceResolver resourceResolver, String contentFragmentPath) {
        logger.info("Reading content fragments");
        ContentFragmentInfo contentFragmentInfo = null;

        try {
            Node node = resourceResolver.getResource(mergeConfigService.getIncomingMergePath() + "/" + contentFragmentPath).adaptTo(Node.class);
            contentFragmentInfo = getContentFragmentInfo(node);
        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return contentFragmentInfo;
    }

    public List<ContentFragmentInfo> getContentFragmentInfoList(ResourceResolver resourceResolver){
        logger.info("Reading content fragments");

        List<ContentFragmentInfo> contentFragmentInfoList = new ArrayList<>();
        try {
            String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
            Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);
            Value[] values = mergeJcrContent.getProperty(BofaJcrUtils.getNamespacedProperty(PROP_CONTENT_FRAGMENT_PATHS)).getValues();
            for (Value value : values) {
                String contentFragmentPath = value.getString();
                String incomingContentFragmentPath = mergeConfigService.getIncomingMergePath() + contentFragmentPath;
                Resource incomingContentFragmentResource = resourceResolver.getResource(incomingContentFragmentPath);
                if (incomingContentFragmentResource == null) {
                    logger.error("Content fragment path not found: {}", incomingContentFragmentPath);
                } else {
                    Node node = Objects.requireNonNull(incomingContentFragmentResource).adaptTo(Node.class);
                    contentFragmentInfoList.add(getContentFragmentInfo(node));
                }
            }

        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return contentFragmentInfoList;
    }


    public List<ContentFragmentInfo> getContentFragmentsMissingModel(ResourceResolver resourceResolver){
        logger.info("Reading content fragments missing model");

        List<ContentFragmentInfo> contentFragmentInfoList = new ArrayList<>();
        try {
            String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
            Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);
            Value[] values = mergeJcrContent.getProperty(BofaJcrUtils.getNamespacedProperty(PROP_CONTENT_FRAGMENT_MISSING_MODEL_PATHS)).getValues();
            for (Value value : values) {
                String contentFragmentPath = value.getString();
                Node node = resourceResolver.getResource(mergeConfigService.getIncomingMergePath() + contentFragmentPath).adaptTo(Node.class);
                contentFragmentInfoList.add(getContentFragmentInfo(node));
            }

        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return contentFragmentInfoList;

    }


    public List<ContentFragmentInfo> getContentFragmentsInTempPath(ResourceResolver resourceResolver, String tempPath){
        logger.info("Reading content fragments in temp path {}", tempPath);

        List<ContentFragmentInfo> contentFragmentInfoList = new ArrayList<>();
        try {
            Node tempPathNode = Objects.requireNonNull(resourceResolver.getResource(tempPath)).adaptTo(Node.class);
//            Resource resource = resourceResolver.getResource(tempPath);
//            Node tempPathNode = resource.adaptTo(Node.class);

            logger.info("Node path: {}", tempPathNode.getPath());


            readNode(tempPathNode, contentFragmentInfoList);
            openContentFragmentMerge(resourceResolver, contentFragmentInfoList);


        } catch (RepositoryException e) {
            logger.error("Error reading content fragments in temp path {}", tempPath, e);
            throw new RuntimeException(e);
        }
        return contentFragmentInfoList;
    }


    public ContentFragmentInfo checkNode(ResourceResolver resourceResolver, String path){
//        logger.info("checkNode path: {}", path);
        ContentFragmentInfo incomingContentFragment = null;

        try {

            Node node = resourceResolver.getResource(path).adaptTo(Node.class);

            boolean isContentFragment = isContentFragment(node);
            if(isContentFragment){
                logger.info("Found content fragment: {}", node.getPath());
                incomingContentFragment = getContentFragmentInfo(node);

                boolean doesContentFragmentModelExist = doesContentFragmentModelExist(resourceResolver, node);
                if(doesContentFragmentModelExist){
                    logger.info("incomingContentFragment.setMissingContentFragmentModel(false);");
                    incomingContentFragment.setMissingContentFragmentModel(false);
                } else {
                    incomingContentFragment.setMissingContentFragmentModel(true);
                    ModifiableValueMap valueMap = Objects.requireNonNull(resourceResolver.getResource(node.getPath() + "/" + JcrConstants.JCR_CONTENT)).adaptTo(ModifiableValueMap.class);
                    valueMap.put("missingContentFragmentModel", true);

                    logger.error("Content fragment model does not exist for path {}", path);
                }

            }

        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return incomingContentFragment;

    }


    private void openContentFragmentMerge(ResourceResolver resourceResolver, List<ContentFragmentInfo> contentFragmentInfoList) throws RepositoryException {

        for (ContentFragmentInfo contentFragmentInfo : contentFragmentInfoList) {

            Node tmpContentFragmentNode = Objects.requireNonNull(resourceResolver.getResource(contentFragmentInfo.getContentFragmentTempPath() + "/" + JcrConstants.JCR_CONTENT)).adaptTo(Node.class);
            tmpContentFragmentNode.setProperty(BofaJcrUtils.getNamespacedProperty("status"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_OPEN);

        }

    }


    private void readNode(Node node, List<ContentFragmentInfo> contentFragmentInfoList) throws RepositoryException {
        logger.info("Reading node {}", node.getPath());

        if(isFolder(node)){
            for (NodeIterator it = node.getNodes(); it.hasNext(); ) {
                Node childNode = (Node) it.next();
                readNode(childNode, contentFragmentInfoList);

            }
        } else {
            if(!StringUtils.equals(node.getName(), "jcr:content")){
                logger.info("    need to check diff {}", node.getPath());

                boolean isContentFragment = isContentFragment(node);
                logger.info("    is content fragment {}", isContentFragment);

                if(isContentFragment){
                    ContentFragmentInfo contentFragmentInfo = getContentFragmentInfo(node);

                    contentFragmentInfoList.add(contentFragmentInfo);
                }

            }
        }
    }

    private ContentFragmentInfo getContentFragmentInfo(Node node) throws RepositoryException {
        Node jcrContent = node.getNode("jcr:content");
        Node data = jcrContent.getNode("data");

        String nodeName = node.getName();
        String tempPath = StringUtils.removeEnd(node.getPath(), "/" + nodeName);
        String parentPath = StringUtils.removeStart(tempPath, mergeConfigService.getIncomingMergePath());
//        logger.info("nodeName: {}, tempPath: {}, parentPath: {}", nodeName, tempPath, parentPath);

        String title = jcrContent.getProperty("jcr:title").getString();
        String model = data.getProperty("cq:model").getString();

        ContentFragmentInfo contentFragmentInfo = new ContentFragmentInfo();
        contentFragmentInfo.setContentFragmentTempPath(node.getPath());
        contentFragmentInfo.setContentFragmentPath(parentPath + "/" + node.getName());
        contentFragmentInfo.setContentFragmentParentPath(parentPath);
        contentFragmentInfo.setName(nodeName);
        contentFragmentInfo.setTitle(title);
        contentFragmentInfo.setModelPath(model);

        return contentFragmentInfo;
    }

    private boolean isFolder(Node node) throws RepositoryException {
        return node.isNodeType("nt:folder") || node.isNodeType("sling:OrderedFolder");
    }


    private boolean isContentFragment(Node node) throws RepositoryException {
        if(node.isNodeType("dam:ContentFragment")){
            return true;
        } else if(node.isNodeType("dam:Asset")) {
            Node jcrContent = node.getNode("jcr:content");
            return jcrContent.hasProperty("contentFragment") && jcrContent.getProperty("contentFragment").getBoolean();
        } else {
            return false;
        }

    }

    private boolean doesContentFragmentModelExist(ResourceResolver resourceResolver, Node node) throws RepositoryException {

        Node dataNode = node.getNode(JcrConstants.JCR_CONTENT).getNode("data");
        ValueMap vm = Objects.requireNonNull(resourceResolver.getResource(dataNode.getPath())).adaptTo(ValueMap.class);
        String modelPath = vm.get("cq:model", String.class);

        Resource resource = resourceResolver.getResource(modelPath);
        return resource != null;

    }


}
