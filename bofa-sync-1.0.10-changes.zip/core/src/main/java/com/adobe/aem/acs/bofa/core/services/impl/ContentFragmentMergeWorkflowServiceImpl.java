package com.adobe.aem.acs.bofa.core.services.impl;

import com.adobe.aem.acs.bofa.core.constants.BofaSyncConstants;
import com.adobe.aem.acs.bofa.core.models.*;
import com.adobe.aem.acs.bofa.core.services.*;
import com.adobe.aem.acs.bofa.core.util.BofaJcrUtils;
import com.day.crx.JcrConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.*;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.*;
import java.util.*;

import static com.adobe.aem.acs.bofa.core.constants.BofaJcrPropertyConstants.*;

@Component(service = {ContentFragmentMergeWorkflowService.class}, immediate = true)
public class ContentFragmentMergeWorkflowServiceImpl implements ContentFragmentMergeWorkflowService {

    private static final Logger logger = LoggerFactory.getLogger(ContentFragmentMergeWorkflowServiceImpl.class);


    @Reference
    private ContentFragmentService contentFragmentService;

    @Reference
    private ContentFragmentMergeService contentFragmentMergeService;

    @Reference
    private MergeConfigService mergeConfigService;

    @Reference
    private MetadataService metadataService;

    @Reference
    private MetadataMergeService metadataMergeService;


    public List<ContentFragmentInfo> startContentFragmentMerge(ResourceResolver resourceResolver){
        logger.debug("Starting Content Fragment merge workflow");

        List<ContentFragmentInfo> contentFragmentInfoList = new ArrayList<>();
        try {

            String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
            Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);

            ModifiableValueMap properties = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(ModifiableValueMap.class);
            String[] incomingContentFragmentPathsArr = properties.get(BofaJcrUtils.getNamespacedProperty(PROP_INCOMING_CONTENT_FRAGMENT_PATHS), new String[0]);
            List<String> incomingContentFragmentPaths = Arrays.asList(incomingContentFragmentPathsArr);
            logger.info("Incoming Content Fragment paths: " + StringUtils.join(incomingContentFragmentPaths, ","));


            // get ContentFragmentInfo for each incoming path
            for (String incomingContentFragmentPath : incomingContentFragmentPaths) {
                contentFragmentInfoList.add(contentFragmentService.getContentFragmentInfo(resourceResolver, incomingContentFragmentPath));
            }


            // get the list of existing content fragment paths stored in PROP_CONTENT_FRAGMENT_PATHS
            List<String> current = Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty(PROP_CONTENT_FRAGMENT_PATHS), new String[0]));
            logger.info("Existing Content Fragment paths: {}", StringUtils.join(current, ","));

            Set<String> existingContentPathSet = new HashSet<>(current);
            existingContentPathSet.addAll(incomingContentFragmentPaths);

            List<String> currentMetadataPaths = Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty(PROP_ASSET_METADATA_PATHS), new String[0]));
            logger.info("Existing Asset Metadata paths: {}", StringUtils.join(currentMetadataPaths, ","));
            Set<String> existingAssetMetadataSet = new HashSet<>(currentMetadataPaths);


            // start import
            for(ContentFragmentInfo contentFragmentInfo : contentFragmentInfoList){
                logger.info("starting with contentFragmentInfo: {}", contentFragmentInfo.getContentFragmentPath());

                Node incomingContentFragmentNodeJcrContent = Objects.requireNonNull(resourceResolver.getResource(contentFragmentInfo.getContentFragmentTempPath() + "/" + JcrConstants.JCR_CONTENT)).adaptTo(Node.class);
                incomingContentFragmentNodeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_OPEN);

                // get all merge data and update hasMergeConflicts
                Node dataNode = incomingContentFragmentNodeJcrContent.getNode("data");
                for(NodeIterator nodeIterator = dataNode.getNodes(); nodeIterator.hasNext();){
                    Node variationNode = nodeIterator.nextNode();
                    variationNode.setProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus"), "");
                }
                ContentFragmentMerge contentFragmentMerge = contentFragmentMergeService.getContentFragmentMerge(resourceResolver, contentFragmentInfo);
                boolean hasMergeConflicts = false;
                for(ContentFragmentVariation contentFragmentVariation : contentFragmentMerge.getVariations()){
                    if(!contentFragmentVariation.isAutoMerge()){
                        hasMergeConflicts = true;
                    }

                    // set mergeStatus
                    Node variationNode = incomingContentFragmentNodeJcrContent.getNode("data").getNode(contentFragmentVariation.getName());
                    if(contentFragmentVariation.isContentIdentical()){
                        variationNode.setProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_IGNORE);
                    } else {
                        variationNode.setProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_OPEN);
                    }

                }

                Node contentFragmentNodeJcrContent = Objects.requireNonNull(resourceResolver.getResource(contentFragmentInfo.getContentFragmentPath() + "/" + JcrConstants.JCR_CONTENT)).adaptTo(Node.class);
                logger.info("Content Fragment hasMergeConflicts: {}", hasMergeConflicts);
                Node contentFragmentMetadata = contentFragmentNodeJcrContent.getNode("metadata");
                contentFragmentMetadata.setProperty(BofaJcrUtils.getNamespacedProperty("hasMergeConflict"), hasMergeConflicts);


                List<String> tempIncomingContentFragmentPaths = new ArrayList<>(Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty(PROP_INCOMING_CONTENT_FRAGMENT_PATHS), new String[0])));
                tempIncomingContentFragmentPaths.remove(contentFragmentInfo.getContentFragmentPath());
                if(tempIncomingContentFragmentPaths.isEmpty()){
                    properties.replace(BofaJcrUtils.getNamespacedProperty(PROP_INCOMING_CONTENT_FRAGMENT_PATHS), new String[0]);
                } else {
                    properties.put(BofaJcrUtils.getNamespacedProperty(PROP_INCOMING_CONTENT_FRAGMENT_PATHS), tempIncomingContentFragmentPaths);
                }

                // check metadata
                MetadataMergeMetadata metadataMergeMetadata = metadataService.getMetadataMergeMetadata(resourceResolver, contentFragmentInfo.getContentFragmentPath());
                MetadataMerge metadataMerge = metadataMergeService.getMetadataMerge(resourceResolver, metadataMergeMetadata);
                if(metadataMerge != null && !metadataMerge.isContentIdentical()){
                    // content fragment metadata is different
                    logger.info("Content Fragment Metadata is not the same, TODO");
                    existingAssetMetadataSet.add(contentFragmentInfo.getContentFragmentPath());
                    incomingContentFragmentNodeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty("mergeMetadataStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_OPEN);

                }


                existingContentPathSet.add(contentFragmentInfo.getContentFragmentPath());


            } // end import

            // set the new list of content fragment paths in PROP_CONTENT_FRAGMENT_PATHS
            List<String> updatedContentFragmentPaths = new ArrayList<>(existingContentPathSet);
            logger.info("Updated content fragment paths: {}", StringUtils.join(updatedContentFragmentPaths, ","));

            mergeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty(PROP_CONTENT_FRAGMENT_PATHS), updatedContentFragmentPaths.toArray(new String[0]));
//            logger.info("contentFragmentPaths: {}", StringUtils.join(contentFragmentPaths, ", "));

            List<String> updatedMetadataPaths = new ArrayList<>(existingAssetMetadataSet);
            logger.info("Updated metadata paths: {}", StringUtils.join(updatedMetadataPaths, ","));
            properties.put(BofaJcrUtils.getNamespacedProperty(PROP_ASSET_METADATA_PATHS), updatedMetadataPaths.toArray(new String[0]));


        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

        return contentFragmentInfoList;
    }


    public void addContentFragmentMissingModel(ResourceResolver resourceResolver, ContentFragmentInfo contentFragmentInfo) {

        logger.debug("Adding content fragment missing model for path {}", contentFragmentInfo.getContentFragmentPath());

        try {

            String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
            Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);

            List<String> incomingContentFragmentPaths = List.of(contentFragmentInfo.getContentFragmentPath());
            logger.info("Current Content Fragment Paths: " + StringUtils.join(incomingContentFragmentPaths, ","));

            ModifiableValueMap properties = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(ModifiableValueMap.class);
            List<String> current = new ArrayList<>(Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty("contentFragmentMissingModelPaths"), new String[0])));
            logger.info("Current Content Fragment Paths: " + StringUtils.join(current, ","));

            Set<String> pathSet = new HashSet<>(current);
            pathSet.addAll(incomingContentFragmentPaths);

            List<String> contentFragmentPaths = new ArrayList<>(pathSet);
            logger.info("New content fragment paths: " + StringUtils.join(contentFragmentPaths, ","));

            mergeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty(PROP_CONTENT_FRAGMENT_MISSING_MODEL_PATHS), contentFragmentPaths.toArray(new String[0]));
            logger.info("contentFragmentPaths: {}", StringUtils.join(contentFragmentPaths, ", "));


        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

    }


    public void removeContentFragmentMissingModel(ResourceResolver resourceResolver, ContentFragmentInfo contentFragmentInfo) {

        logger.debug("Removing content fragment missing model for path {}", contentFragmentInfo.getContentFragmentPath());

        String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
        Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);

        ModifiableValueMap properties = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(ModifiableValueMap.class);
        List<String> contentFragmentMissingModelPaths = new ArrayList<>(Arrays.asList(properties.get(BofaJcrUtils.getNamespacedProperty("contentFragmentMissingModelPaths"), new String[0])));
        logger.info("removeContentFragmentMissingModel before contentFragmentMissingModelPaths: " + StringUtils.join(contentFragmentMissingModelPaths, ","));

        contentFragmentMissingModelPaths.remove(contentFragmentInfo.getContentFragmentPath());

        logger.info("removeContentFragmentMissingModel after contentFragmentMissingModelPaths: " + StringUtils.join(contentFragmentMissingModelPaths, ","));
        properties.put(BofaJcrUtils.getNamespacedProperty(PROP_CONTENT_FRAGMENT_MISSING_MODEL_PATHS), contentFragmentMissingModelPaths.toArray(new String[0]));
        logger.info("in here resolver.hasChanges: {}", resourceResolver.hasChanges());

//        properties.remove("");

    }



    public void closeContentFragmentMerge(ResourceResolver resourceResolver, String contentFragmentPath, String variationName){
        logger.debug("Closing Content Fragment Variation Merge variationName: {}, contentFragmentPath: {}", variationName, contentFragmentPath);

        try {

            ContentFragmentInfo contentFragmentInfo = contentFragmentService.getContentFragmentInfo(resourceResolver, contentFragmentPath);

            String contentFragmentJcrContentPath = contentFragmentInfo.getContentFragmentTempPath() + "/" + JcrConstants.JCR_CONTENT;
            Node contentFragmentJcrContent = Objects.requireNonNull(resourceResolver.getResource(contentFragmentJcrContentPath)).adaptTo(Node.class);
            assert contentFragmentJcrContent != null;

            ContentFragmentMerge contentFragmentMerge = contentFragmentMergeService.getContentFragmentMerge(resourceResolver, contentFragmentInfo);

            ContentFragmentVariation variation = contentFragmentMerge.getVariation(variationName);
            if(variation.isContentIdentical()){
                logger.info("Close content fragment merge for variation: {} content fragment: {}", variation.getName(), contentFragmentJcrContent.getPath());
                Node variationNode = contentFragmentJcrContent.getNode("data").getNode(variation.getName());
                variationNode.setProperty(BofaJcrUtils.getNamespacedProperty("mergeStatus"), BofaSyncConstants.BOFA_SYNC_CONTENT_FRAGMENT_MERGE_CLOSED);
            } else {
                throw new IllegalStateException("Cannot close content fragment merge, content is not the same");
            }

        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }


    }


    public void endContentFragmentMerge(ResourceResolver resourceResolver){
        logger.info("End content fragment merge workflow");

        try {
            String mergeJcrContentPath = BofaSyncConstants.BOFA_SYNC_MERGE_PATH + "/" + JcrConstants.JCR_CONTENT;
            Node mergeJcrContent = Objects.requireNonNull(resourceResolver.getResource(mergeJcrContentPath)).adaptTo(Node.class);
            mergeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty("status"), BofaSyncConstants.BOFA_SYNC_WORKFLOW_CLOSED);
            mergeJcrContent.setProperty(BofaJcrUtils.getNamespacedProperty(PROP_CONTENT_FRAGMENT_PATHS), new String[]{});

            Node tmpPath = Objects.requireNonNull(resourceResolver.getResource(mergeConfigService.getIncomingMergePath())).adaptTo(Node.class);
            for (NodeIterator it = tmpPath.getNodes(); it.hasNext(); ) {
                Node child = (Node) it.next();
                child.remove();
            }

        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }

    }

}
